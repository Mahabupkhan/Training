package seleniumLearning;

public class N {
	public static void main(String[] args) {
		if(1+1+1+1+1==5) {
			System.out.println("True");
		}
		else System.out.println("False");
	}
}
