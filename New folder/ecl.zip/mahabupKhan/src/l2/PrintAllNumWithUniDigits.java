package l2;

import java.util.Scanner;

public class PrintAllNumWithUniDigits {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.print("Enter staring number : ");
		int start=scan.nextInt();
		System.out.println("Enter ending number : ");
		int end=scan.nextInt();
//		if(start>end) {
//			int temp=start;
//			start=end;
//			end=temp;
//		}
		for(int i=start;;) {
			if(checkUnique(i)) {
				System.out.println(i+" ");
			}
			if(start<end) {
				i++;
				if(start>=end) break;
			}
			else {
				i--;
				if(start<=end) break;
			}
		}
		
	}
	public static boolean checkUnique(Integer n) {
		String n1=n.toString();
		for(int i=0;i<n1.length();i++) {
			for(int j=i+1;j<n1.length();j++) {
				if(n1.charAt(i)==n1.charAt(j)) {
					return false;
				}
			}
		}
		return true;
	}
}
