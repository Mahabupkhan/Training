package l2;

import java.util.Scanner;

public class RealityShow {
	
	public static void main(String[] args) throws InterruptedException {
		Show s=new Show();
		s.met(s);
	}
	
	
}
class Show{
	Scanner scan=new Scanner(System.in);
	int[][] capability=new int[4][3];
	int balls;
	int time;
	int[] teamScore=new int[4];
	Show s;
public void met(Show s) throws InterruptedException {
		this.s=s;
		System.out.println("Enter the total No of balls : ");
		balls=scan.nextInt();
		System.out.println("Enter time taken for team members : ");
		for(int i=0;i<4;i++) {
			for(int j=0;j<3;j++) {
				System.out.println("Enter for Team "+(i+1)+" Member "+(j+1)+" : ");
				capability[i][j]=scan.nextInt();
			}
		}
		System.out.println("Enter total time for the game : ");
		time=60*(scan.nextInt());
		Runnable t1=new Team1();
		Runnable t2=new Team2();
		Runnable t3=new Team3();
		Runnable t4=new Team4();
		Thread r1=new Thread(t1);
		Thread r2=new Thread(t2);
		Thread r3=new Thread(t3);
		Thread r4=new Thread(t4);
		r1.start();
		r2.start();
		r3.start();
		r4.start();
//		for(int i=0;i<4;i++)
//			System.out.println(teamScore[i]+" ");
		int winner=0;
		for(int i=0;i<4;i++) {
			if(teamScore[winner]<teamScore[i]) {
				winner=i;
			}
		}
		System.out.println("Winner : "+(winner+1)+" team");
	}
}
class Team1 extends Show implements Runnable{
	public void run() {
		for(int i=0;i<3;i++) {
			if(balls>0) {
				teamScore[0]+=(time/s.capability[0][i]);
				balls--;
			}
		}
	}
}
class Team2 extends Show implements Runnable{
	public void run() {
		for(int i=0;i<3;i++) {
			if(balls>0) {
				teamScore[1]+=(time/s.capability[1][i]);
				balls--;
			}
		}
	}
}
class Team3 extends Show implements Runnable{
	public void run() {
		for(int i=0;i<3;i++) {
			if(balls>0) {
				teamScore[2]+=(time/s.capability[2][i]);
				balls--;
			}
		}
	}
}
class Team4 extends Show implements Runnable{
	public void run() {
		for(int i=0;i<3;i++) {
			if(balls>0) {
				teamScore[3]+=(time/s.capability[3][i]);
				balls--;
			}
		}
	}
}
