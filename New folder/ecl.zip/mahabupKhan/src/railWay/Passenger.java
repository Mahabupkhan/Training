package railWay;

import java.io.Serializable;

public class Passenger implements Serializable{
	private String name;
	private int age;
	private String gender;
	private int id;
	private int pnr;
	private String ticketStatus;
	private Train train;
	Passenger(String name,int age,String gender,int id,int pnr,String ticketStatus,Train train){
		this.name=name;
		this.age=age;
		this.gender=gender;
		this.id=id;
		this.pnr=pnr;
		this.ticketStatus=ticketStatus;
		this.train=train;
	}
	public String toString() {
		return "Name : "+name+" Id : "+id+" Age : "+age+" gender : "+gender+" PNR : "+pnr+" ticket Status : "+ticketStatus;
	}
	public int getId() {
		return id;
	}
	public String getTicketStatus() {
		return ticketStatus;
	}
	public Train getTrain() {
		return train;
	}
	public int getPnr() {
		return pnr;
	}
	public void setTicketStatus(String s) {
		this.ticketStatus=s;
	}
}
