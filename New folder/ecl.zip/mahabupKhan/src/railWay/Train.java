package railWay;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

public class Train implements Serializable{
	private int trainNo;
	private String trainName;
	//private String from;
	//private String to;
	private int departure;
	private int arrival;
 String[] inBetweenStations;
	private int fair;
	private int seats;
	ArrayList<Passenger> CNF=new ArrayList<Passenger>(10);
	Queue<Passenger> WL=new ConcurrentLinkedQueue<Passenger>();
	Train(int trainNo,String trainName,int departure,int arrival,String[] inBetweenStations,int fair,int seats){
		this.trainNo=trainNo;
		this.trainName=trainName;
		//this.from=from;
		//this.to=to;
		this.departure=departure;
		this.arrival=arrival;
		this.inBetweenStations=inBetweenStations;
		this.fair=fair;
		this.seats=seats;
	}
	public int getArrival() {
		return arrival;
	}
	public int getDeparture() {
		return departure;
	}
//	public String getFrom() {
//		return from;
//	}
	public String[] getInBetweenStations() {
		return inBetweenStations;
	}
//	public String getTo() {
//		return to;
//	}
	public String getTrainName() {
		return trainName;
	}
	public int getTrainNo() {
		return trainNo;
	}
	public int getFair() {
		return fair;
	}
	public int getSeats() {
		return seats;
	}
	public String toString() {
		return "TrainNo : "+trainNo+"|| Train Name : "+trainName+"|| Departure Time : "+departure+
				"|| Arrival Time : "+arrival+"|| Fair : "+fair+"|| Seats : "+seats;
	}
	public void addToCNF(Passenger p) {
		CNF.add(p);
	}
	public void addToWL(Passenger p) {
		WL.add(p);
	}
	public void DecSeats() {
		seats--;
	}
}
