package L2;

import java.util.Scanner;

public class SecondFrequencyInArray {
public static void main(String[] args) {
	Scanner scan=new Scanner(System.in);
	System.out.println("Enter array size : ");
	int n=scan.nextInt();
	int[] arr=new int[n];
	for(int i=0;i<n;i++)
		arr[i]=scan.nextInt();
	int temp=Integer.MAX_VALUE;	
	int min=Integer.MIN_VALUE;
	int value=0;
	for(int i=0;i<n;i++) {
		if(arr[i]!=':') {
		int occur=1;
		for(int j=i+1;j<n;j++) {
			if(arr[i]==arr[j]) {
				occur++;
				arr[j]=':';
			}
		}
		if(occur>min && occur<temp) {
			value=arr[i];
			min=temp;
			temp=occur;
		}
		}
	}
	System.out.println(value);
}
}
