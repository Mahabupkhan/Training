package L2;

public class DyanamicProgramming {
public static void main(String[] args) {
	int n=5;
	dp=new long[n];
	for(int i=0;i<n;i++)
		dp[i]=(long)-1;
	System.out.println(Fib(n));
	
}
static long dp[];
public static long Fib(int n) {
	if(n==0 || n==1)
		return n;
	if(dp[n-1]!=-1)
		return dp[n];
	
	long sum=Fib(n-1)+Fib(n-2);
	dp[n-1]=sum;
	return sum;
	
}
}
