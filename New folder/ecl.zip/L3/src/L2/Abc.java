package L2;

class AbcChild {
	
	public void start() {
		run();
	}
	public void run() {
		System.out.println("Abc run");
	}
}
class Abc extends AbcChild{
	public static void main(String[] args) {
		AbcChild child=new AbcChild();
		child.start();
	}
	public void run() {
		System.out.println("Child of Abc");
	}
	
}
