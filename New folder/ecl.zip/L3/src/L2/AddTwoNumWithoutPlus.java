package L2;


public class AddTwoNumWithoutPlus {
	public static void main(String[] args) {
		Male m1=new Male();
		m1.name="Suthish";
		Male m2=new Male();
		m2.name=""
	}
	 public static int addIterative(int a, int b){  
	        while (b != 0){
	            int carry = (a & b) ; //CARRY is AND of two bits
	          
	            a = a ^b; //SUM of two bits is A XOR B
	          
	            b = carry << 1; //shifts carry to 1 bit to calculate sum
	        }
	        return a;
	 }  
}
abstract class Human{
	String name;
	int age;
	abstract void sayName();
}
class Male extends Human{
	@Override
	void sayName() {
		System.out.println("I am male");
		
	}
}
class Sid extends Male{
	void sayName() {
		System.out.println("my name is "+name);
	}
}

