package L2;

public class XyzChild extends Xyz{
public static void main(String[] args) {
	XyzChild child=new XyzChild();
	child.start();
}
@Override
	public void run() {
		System.out.println("Child Run called");
	}
}
