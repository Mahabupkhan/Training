package L2;

public class Xyz {
public void start() {
	run();
}
public void run() {
	System.out.println("Xyz Running");
}
}
