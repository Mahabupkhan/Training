package L2;

public class OverLoadUsingObject {
	public static void main(String[] args) {
		Human a=new Human("Suthish",15);
		Human b=new Human("Jameel",13);
		a.print1();
		b.print1();
	}
	
	
}
class Human{
	String name;
	int age;
	Human(String name,int age){
		this.name=name;
		this.age=age;
	}
	public int print1() {
		return age;
	}
	public String print1(String name) {
		return name;
	}
}