import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class Deserial {
public static void main(String[] args) {
	Human h=null;
	try {
		FileInputStream fi=new FileInputStream("D:\\Adhil.txt");
		ObjectInputStream oi=new ObjectInputStream(fi);
		h=(Human)oi.readObject();
	}
	catch(Exception e) {
		e.printStackTrace();
	}
	System.out.println(h.name+"  "+h.age);
}
}
