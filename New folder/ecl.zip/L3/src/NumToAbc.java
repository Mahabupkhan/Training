import java.util.Scanner;

public class NumToAbc {
public static void main(String[] args) {
	Scanner scan=new Scanner(System.in);
	int n=scan.nextInt();
	String str="";
	while(n>0) {
		char c=(char)((n-1)%26+'A');
		n=(n-1)/26;
		str=c+str;;
	}
	System.out.println(str );
}
}
