package busReservation;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
class Deserialize{
	public static void main(String[] args){
		dodeSerialize();
	}
	public static void dodeSerialize(){
		ArrayList<Passenger> arr=new ArrayList<Passenger>();
		try{
			FileInputStream fi=new FileInputStream("C:\\Users\\Administrator\\Desktop\\Java\\ContinuosTask\\04 Jan\\L3_serial\\PassengerDetail1.txt");
			ObjectInputStream oi=new ObjectInputStream(fi);
			for(int i=0;i<3;i++){
				arr.add((Passenger)oi.readObject());
			}
		}
		catch(FileNotFoundException e){
			e.printStackTrace();
		}
		catch(ArithmeticException a) {
			
		}
		catch(ClassNotFoundException a) {
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			System.out.println("Name\t\tAge\tGender\t\tphone no\t\tMail\t\t\t\tPickup\t\tDrop\tSeatNo");
			for(int i=0;i<arr.size();i++)
				System.out.println(arr.get(i));
		}
	}
}
