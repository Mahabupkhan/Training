package busReservation;

import java.util.Scanner;

public class Bank implements Online{
	protected Bank() {}
	public void gpay() {
		System.out.println("gpay");
	}
	public void netbanking() {
		System.out.println("Online Trans");
	}
	public void withdraw() {
		System.out.println("withdraw");
	}
	
	
	
}