package busReservation;

import java.util.Scanner;

public interface Online {
public void gpay();
public void netbanking();
public static Bank secure(int i) {

		
		
		if(i==1234)
			return new Bank();
		else
			return null;
		
	
}
}
