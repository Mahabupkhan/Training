package mapInterface;

import java.util.LinkedHashMap;

public class Demo1 {
public static void main(String[] args) {
	LinkedHashMap<String,Stud> lm=new LinkedHashMap<String,Stud>();
	Stud s1=new Stud("Mabu",19);
	lm.put(s1.name, s1);
	Stud s2=new Stud("Mabu",19);
	lm.put(s2.name, s1);
}
}
class Stud{
	String name;
	int age;
	Stud(String name,int age){
		this.name=name;
		this.age=age;
	}
	public String toString() {
		return "Name : "+name+"\nAge : "+age;
	}
}
