import java.util.Scanner;
public class concetrix {
	

		public static void main(String[] args){
			Scanner sc = new Scanner(System.in);
			int num=sc.nextInt();
			int n =num*2-1;
			//System.out.println(n);
			int s=n;
			int l=0;
			int r=n-1;
			
			int arr[][]= new int[n][n];
	        while(num!=0)
			{
				for(int i=l;i<=r;i++)
				{
					for(int j=l;j<=r;j++)
					{
						if(i==l||i==r||j==l||j==r)
						{
							arr[i][j]=num;
						}
					}
				}
				l++;r--;num--;
			}
			for(int i=0;i<s;i++)
			{
				for(int j=0;j<s;j++)
				{
					System.out.print(arr[i][j]);
				}
				System.out.println();
			}
				
		}}
	

