
public class CheckParanthesis {
public static void main(String[] args) {
	long st=System.currentTimeMillis();
	String s="(]";
	System.out.println(checkLeftToRight(s) && checkRightToLeft(s));
	System.out.println(System.currentTimeMillis()-st);
}
public static boolean checkLeftToRight(String s) {
    int len = s.length();
    int left = 0, right = 0, star = 0;
    for(int i=0; i<len; i++) {
        char ch = s.charAt(i);
        if(ch=='(') {
            left++;
        } else if(ch==')') {
            right++;
        } else {
            star++;
        }
        if(left+star < right) return false;
    }
    return true;
}

public static boolean checkRightToLeft(String s) {
    int len = s.length();
    int left = 0, right = 0, star = 0;
    for(int i=len-1; i>=0; i--) {
        char ch = s.charAt(i);
        if(ch=='(') {
            left++;
        } else if(ch==')') {
            right++;
        } else {
            star++;
        }
        if(right+star < left) return false;
    }
    return true;
}
}
