import java.util.ArrayList;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.Serializable;
public class DeserialDemo {
public static void main(String[] args) {
	ArrayList<Emp> arr=new ArrayList<Emp>();
	try {
		FileInputStream in=new FileInputStream("D:\\Drago.txt");
		ObjectInputStream oi=new ObjectInputStream(in);
		for(int i=0;i<3;i++) {
			arr.add((Emp)oi.readObject());
		}
		System.out.println("Deserialized");
	}
	catch(Exception e) {
		e.printStackTrace();
	}
	System.out.println(arr);
}
}
