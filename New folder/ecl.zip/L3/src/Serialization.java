import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class Serialization {
public static void main(String[] args) {
	Human h=new Human("Adhil",21);
	try {
		FileOutputStream p=new FileOutputStream("D:\\Adhil.txt");
		ObjectOutputStream o=new ObjectOutputStream(p);
		o.writeObject(h);
		System.out.println("Serialized");
	}
	catch(Exception c) {
		c.printStackTrace();
	}
}
}
class Human implements Serializable{
	String name;
	int age;
	Human(String name,int age){
		this.name=name;
		this.age=age;
	}
}