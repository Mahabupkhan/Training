package lambdaExpression;

public class MethodReferencing {
public static void main(String[] args) {
	//MethodReferencing m=new MethodReferencing();
	Inter a=MethodReferencing::haha;
	a.met();
	
}
public static Integer haha() {
	System.out.println("haha");
	return 1;
}
}
interface Inter{
	public Integer met();
}
