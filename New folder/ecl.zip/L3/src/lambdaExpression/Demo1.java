package lambdaExpression;

public class Demo1 {
public static void main(String[] args) {
	 Lambda l=()->System.out.println("lambda Expression");
	 l.met();
	 l.met2();
}
}
interface Lambda{
	public void met();
	static void met1() {
		System.out.println("This is static method");
	}
	default void met2() {
		System.out.println("This is default method");
	}
}