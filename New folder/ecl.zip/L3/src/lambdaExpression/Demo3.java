package lambdaExpression;

public class Demo3 {
public static void main(String[] args) {
	
	Runnable r=new Demo3()::met;
	Thread t=new Thread(r);
	t.start();
	for(int i=0;i<4;i++)
		System.out.println("Main..."+i);
	
}
public  int met() {
	for(int i=0;i<4;i++)
		System.out.println("Run..."+i);
	return 10;
}

}

