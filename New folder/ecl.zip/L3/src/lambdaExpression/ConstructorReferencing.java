package lambdaExpression;

public class ConstructorReferencing {
public static void main(String[] args) {
	A a=Sample::new;
	Sample s1=a.get(4);
	s1.met();
}
}
interface A extends B{
	public Sample get(int a);
}
interface B{
	default void e() {}
}
class Sample{
	Sample(int a){
		System.out.println("Cons called");
	}
	public void met() {
		System.out.println("Met ");
	}
}