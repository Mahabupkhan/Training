import java.util.Scanner;

public class Stringrev {
public static void main(String[] args) {
	Scanner scan=new Scanner(System.in);
	String str=scan.nextLine();
	System.out.println(rev(str,"","",0));
}
public static String rev(String str,String word,String rev,int ind) {
	if(ind==str.length()) 
		return word+rev.charAt(rev.length()-1)+rev;
	if(str.charAt(ind)>='a' && str.charAt(ind)<='z' || str.charAt(ind)>='A' && str.charAt(ind)<='Z') 
		return rev(str,word+str.charAt(ind),rev,ind+1);
	else 
		return rev(str,"",word+str.charAt(ind)+rev,ind+1);
	
}
}
