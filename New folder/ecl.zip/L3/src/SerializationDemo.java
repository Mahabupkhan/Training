import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class SerializationDemo {
public static void main(String[] args) {
	Student s1=new Student("kadhar",8001);
	Student s2=new Student("ashath",8002);
	try {
		FileOutputStream fileout=new FileOutputStream("D:\\Students.txt");
		ObjectOutputStream out=new ObjectOutputStream(fileout);
		out.writeObject(s1);
		out.writeObject(s2);
		out.close();
		fileout.close();
		System.out.println("Serial completed");
	}
	catch(Exception e) {
		e.printStackTrace();
	}
}
}
class Student implements Serializable{
	/**
	 * 
	 */
	//private static final long serialVersionUID = 1L;
	String n;
	int roll;
	Student(String name,int roll){
		this.n=name;
		this.roll=roll;
	}
	public String toString() {
		return n+"\t"+roll;
	}
}
