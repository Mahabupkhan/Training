package dataStructures;

public class DoubleLinkedList {
	
	static class Node{
		Object data;
		int prev;
		int next;
		Node(Object o){
			this.data=o;
		}
	}
}
