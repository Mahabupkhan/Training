package dataStructures;

public class ArrayListDemo {
	int index=0;
	int size;
	Object[] obj;
	Object[] temp;
	public ArrayListDemo(int size) {
		this.size=size;
		obj=new Object[size];
	}
	public ArrayListDemo() {
		this.size=1;
		obj=new Object[size];
	}
	public boolean add(Object o) {
		if(index<size) {
			obj[index++]=o;
			return true;
		}
		else {
			size++;
			temp=new Object[size+1];
			int i;
			for(i=0;i<obj.length;i++) {
				temp[i]=obj[i];
		}
			temp[i]=o;
			obj=temp;
			temp=null;
			return true;
		}
	}
	public boolean add(int i,Object o) {
		if(i<size) {
			size++;
			temp=new Object[size+1];
			int j;
			for(j=0;j<i;j++) {
				temp[j]=obj[j];
			}
			temp[j]=o;
			for(int k=i+1;k<size;k++) {
				temp[k]=obj[k];
			}
			obj=temp;
			temp=null;
			return true;
		}
		else {
			int currSize=size;
			size=size+(i-size)+1;
			temp=new Object[size];
			for(int j=0;j<currSize;j++) {
				temp[j]=obj[j];
			}
			temp[i]=o;
			obj=temp;
			temp=null;
			return true;
			
		}
	}
}
