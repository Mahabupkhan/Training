package dataStructures;

public class Test {
public static void main(String[] args) {
	ArrayListDemo arr=new ArrayListDemo(2);
	arr.add(0);
	arr.add(1);
	arr.add(3);
	arr.add(4);
	arr.add(2,2);
	for(int i=0;i<arr.size;i++) {
		System.out.println(arr.obj[i]);
	}
	System.out.println(arr.size);
}
}
