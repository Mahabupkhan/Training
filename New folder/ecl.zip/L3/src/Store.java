import busReservation.Online;
import busReservation.Bank;
public class Store {
public static void main(String[] args) {
	store2 s=new store2();
	s.met();
}
}
class store2{
	void met() {
		Bank b=Online.secure(1234);
		b.gpay();
	}
}