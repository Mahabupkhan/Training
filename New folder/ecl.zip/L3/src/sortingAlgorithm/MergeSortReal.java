package sortingAlgorithm;

import java.util.Arrays;
import java.util.Scanner;

public class MergeSortReal {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter Array Size : ");
		int size=scan.nextInt();
		int[] arr=new int[size];
		for(int i=0;i<size;i++)
			arr[i]=scan.nextInt();
		divide(arr,0,size-1);
		System.out.println(Arrays.toString(arr));
	}
	public static void divide(int[] arr,int lb,int ub) {
		if(lb<ub) {
			int mid=(lb+ub)/2;
			divide(arr,lb,mid);
			divide(arr,mid+1,ub);
			join(arr,lb,mid,ub);
		}
	}
	public static void join(int[] arr,int lb,int mid,int ub) {
		int i=lb;
		int j=mid+1;
		int k=0;
		int[] ans=new int[(ub-lb)];
		while(i<=mid && j<=ub) {
			if(arr[i]<=arr[j]) {
				ans[k++]=arr[i++];
			}
			else {
				ans[k++]=arr[j++];
			}
		}
		if(i>mid) {
			while(j<=ub) {
				ans[k++]=arr[j++];
			}
		}
		else {
			while(i<=ub) {
				ans[k++]=arr[i++];
			}
		}
		int o=0;
		for(int m=lb;m<=ub;m++)
			arr[m]=ans[o++];
	}
}
