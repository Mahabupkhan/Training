package sortingAlgorithm;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Scanner;

public class MergeSort {
public static void main(String[] args) {
	Scanner scan=new Scanner(System.in);
	int size=scan.nextInt();
	int[] arr=new int[size];
	for(int i=0;i<size;i++)
		arr[i]=scan.nextInt();
	System.out.println(Arrays.toString(divide(arr)));
}
public static int[] divide(int[] arr) {
	//System.out.println(Arrays.toString(arr));
	if(arr.length==1)
		return arr;
	int mid=arr.length/2;
	int[] left=divide(arrayCopy(arr,0,mid));
	System.out.println(Arrays.toString(left));
	int[] right=divide(arrayCopy(arr,mid,arr.length));
	return conquere(left,right);
	//long n=System.currentTimeMillis();
}
public static int[] arrayCopy(int[] arr,int start,int end) {
	int[] ans=new int[end-start];
	int k=0;
	for(int i=start;i<end;i++)
		ans[k++]=arr[i];
	return ans;
}
public static int[] conquere(int[] left,int[] right) {
	int joined[]=new int[left.length+right.length];
	int i=0,j=0,k=0;
	while(i<left.length && j<right.length) {
		if(left[i]<right[j]) {
			joined[k++]=left[i++];
		}
		else {
			joined[k++]=right[j++];
		}
	}

	while(i<left.length)
		joined[k++]=left[i++];
	while(j<right.length)
		joined[k++]=right[j++];
	return joined;
}
}
