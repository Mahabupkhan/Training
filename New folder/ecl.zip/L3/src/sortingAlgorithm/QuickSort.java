package sortingAlgorithm;

import java.util.Arrays;
import java.util.Scanner;

public class QuickSort {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter Array Size : ");
		int size=scan.nextInt();
		int[] arr=new int[size];
		for(int i=0;i<size;i++)
			arr[i]=scan.nextInt();
		quickSort(arr,0,arr.length-1);
		System.out.println(Arrays.toString(arr));
	}
	public static int divide(int[] arr,int lb,int ub) {
		int pivot=arr[lb];
		int start=lb;
		int end=ub;
		while(start<end) {
			while(arr[start]<=pivot) {
				start++;
			}
			while(arr[end]>pivot) {
				end--;
			}
			if(start<end) {
				int temp=arr[start];
				arr[start]=arr[end];
				arr[end]=temp;
				
			}
		}
		int temp=arr[end];
		arr[end]=arr[lb];
		arr[lb]=temp;	
		return end;
	}
	public static void quickSort(int[] arr,int lb,int ub) {
		if(lb<ub) {
		int location=divide(arr,lb,ub);
		quickSort(arr,lb,location-1);
		quickSort(arr,location+1,ub);
		}
		
	}
}
