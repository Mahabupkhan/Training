package sortingAlgorithm;

import java.util.Scanner;

public class SelectionSort {
public static void main(String[] args) {
	Scanner scan=new Scanner(System.in);
	System.out.println("Enter Array Size : ");
	int size=scan.nextInt();
	int[] arr=new int[size];
	for(int i=0;i<size;i++)
		arr[i]=scan.nextInt();
	for(int i=0;i<size;i++) {
		int minIndex=i;
		for(int j=i+1;j<size;j++) {
			if(arr[minIndex]>arr[j]) {
				minIndex=j;
			}
		}
		int temp=arr[minIndex];
		arr[minIndex]=arr[i];
		arr[i]=temp;
	}
	for(int i:arr)
		System.out.print(i+" ");
		
	
}
}
