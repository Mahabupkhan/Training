
public class Abst {
public static void main(String[] args) {
	H h=new Male();
	h.eat();
}
}
abstract class H{
	abstract void eat();
}
class Male extends H{
	@Override
	void eat() {
		System.out.println("Eating....");
		
	}
	void swim() {
		System.out.println("Swimming");
	}
}