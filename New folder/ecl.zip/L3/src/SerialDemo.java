import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Scanner;

public class SerialDemo {
public static void main(String[] args) {
	Scanner scan=new Scanner(System.in);
	try {
		FileOutputStream out=new FileOutputStream("D:\\Drago.txt");
		ObjectOutputStream os=new ObjectOutputStream(out);
		for(int i=0;i<3;i++) {
			System.out.println("Enter name : ");
			String name=scan.next();
			System.out.println("Enter id : ");
			int id=scan.nextInt();
		Emp e=new Emp(name,id);
		os.writeObject(e);
		System.out.println("serialized");
		}
	}
	catch(Exception t) {
		t.printStackTrace();
	}
}
}
class Emp implements Serializable{
	String name;
	int id;
	Emp(String name,int id){
		this.name=name;
		this.id=id;
	}
	public String toString() {
		return name+"\t"+id;
	}
}
