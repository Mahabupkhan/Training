
public class GcDemo {
public static void main(String[] args) {
	GcDemo gc = new GcDemo();
	gc=null;
	
}
}
