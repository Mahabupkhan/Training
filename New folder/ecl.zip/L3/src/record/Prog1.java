package record;

import java.util.ArrayList;

public class Prog1 {
public static void main(String[] args) {
	ArrayList<Emp> arr=new ArrayList<Emp>();
	Emp e1=new Emp("Suthish",1,21);
	Emp e2=new Emp("mabu",1,21);
	Emp e3=new Emp("affru",1,21);
	Emp e4=new Emp("ashath",1,21);
	Emp e5=new Emp("aadhil",121);
	arr.add(e1);
	arr.add(e2);
	arr.add(e3);
	arr.add(e4);
	arr.add(e5);
	for(int i=0;i<arr.size();i++)
		System.out.println(arr.get(i));
	
}
}
record Emp(String name,int id,int age) {
	public Emp(String name,int id){
		this(name,id,20);
	}
	public String toString() {
		return name+"  "+id+"  "+age;
	}
}