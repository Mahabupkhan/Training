package record;

public class A {
	public static void main(String[] args) {
		Mabu m=new Mabu();
		System.out.println(m.name+" "+m.age);
		//Object a=(Object) Class.forName("Object").newInstance();
		//a.met();
		System.out.println(m.getClass());
	}
}
abstract class Human{
	String name;
	int age;
	
}
class Male extends Human{
	Male(){
		//super("Mabu",21);
		System.out.println("Male cons");
		
	}
}
class Mabu extends Male{
	Mabu(){
		System.out.println("Mabu cons");
	}
}
class Object{
	public void met() {
		System.out.println("Metttttttt");
	}
}