package record;

public class ConstructorPrint {
public static void main(String[] args) {
	System.out.println(new Num(3));
}
}
class Num{
	int i;
	Num(int i){
		this.i=i;
	}
}