package multiThreading;

public class Demo2 {
@SuppressWarnings("deprecation")
public static void main(String[] args) throws InterruptedException {
	Thread5 t=new Thread5();
	System.out.println(t.getState());
	t.start();
	t.join();
	t.start();
	t.setPriority(1);
	System.out.println(t.getState());
	for(int i=0;i<=5;i++)
		System.out.println("Main..."+i);
	System.out.println(t.getState());
	t.setName("baby");
	System.out.println(t.getName());
	System.out.println(t.getPriority());
	
}

}
class Thread5 extends Thread{
	public void run() {
		for(int i=0;i<=5;i++) {
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Thread..."+i);
			
		}
		a();
		b();
	}
	public void a() {
		for(int i=0;i<=5;i++) {
			System.out.println("a..."+i);
		}
	}
	public void b() {
		for(int i=0;i<=5;i++) {
			System.out.println("b..."+i);
			
		}
	}
}
