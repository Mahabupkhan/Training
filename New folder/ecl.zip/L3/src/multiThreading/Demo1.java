package multiThreading;

public class Demo1 {
public static void main(String[] args) {
	Thread1 t=new Thread1();
	t.start();
	for(int i=0;i<=5;i++) {
		System.out.println("Main Thread..."+i);
	}
	
	
	
}
}
class Thread1 extends Thread{
	@Override
	public void run() {
		A a=new A();
		for(int i=0;i<=5;i++) {
			System.out.println("Thread1..."+i);
			
		}
		a.met();
	}
}
class A{
	public void met() {
		for(int i=0;i<=5;i++) {
			System.out.println("met..."+i);
			
		}
	}
}
