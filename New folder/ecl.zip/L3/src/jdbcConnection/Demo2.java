package jdbcConnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Demo2 {
public static void main(String[] args) {
	Connection con;
	try {
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/batch5","root","root");
		Statement stmt=con.createStatement();
		ResultSet rs=stmt.executeQuery("Select * from student1");
	}catch (SQLException e) {
		e.printStackTrace();
	}
	if(true) {
		
	}
	met();
}
public static void met() {
	System.out.println("met");
}
}
