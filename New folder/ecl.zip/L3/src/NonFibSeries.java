
public class NonFibSeries {
public static void main(String[] args) {
  int k=20;
  int start1=1;
  int start2=1;
  while(k>=1) {
	  int i;
	  for(i=start1+1;i<start2;i++ ) {
		  System.out.print(i+" ");
		  k--;
	  }
	  System.out.println(i+" ");
	  
  }
}
}
