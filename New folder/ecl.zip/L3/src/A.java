
public class A {
public static void main(String[] args) {
	
	long a=24l*60l*60l*1000l;
	long a1=86400000;
	System.out.println((a==a1));
	long b=24l*60l*60l*1000l*1000l;
	int z = 24*60*60*1000*1000;
	int y=24*60*60*1000;
	System.out.println("z="+z);
	System.out.println("ans="+(b/a));
	long b1=500654080;
	System.out.println(b==b1);
	System.out.println("b = "+b);
	System.out.println(a*1000);
	System.out.println(Math.pow(2, 63)-1==Long.MAX_VALUE);

}
}
