package encapsulation;

public class Exe4 {
public static void main(String[] args) {
	Rectangle r=new Rectangle();
	r.setWidth(10);
	r.setHeight(5);
	int i=r.area();
	System.out.println(i);
}
}
class Rectangle{
	private int width;
	private int height;
	public int area() {
		return width*height;
	}
	public void setWidth(int Width) {
		this.width=Width;
	}
	public void setHeight(int Height) {
		this.height=Height;
	}
}