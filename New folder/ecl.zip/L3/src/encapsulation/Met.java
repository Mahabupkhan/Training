package encapsulation;

public class Met {
public static void main(String[] args) {
	Met3 m=new Met3(5);
	m.met2();
}
}
class Met2{
	int i=0;
	Met2(int i){
		this.i=i;
		System.out.println(i);
	}
	public static void met() {
		System.out.println("Met 2 class");
	}
	
}
class Met3 extends Met2{
	Met3(int s){
		super(s);
	}
	int i=10;
	public void met2() {
		System.out.println("Met3 Class"+super.i);
	}
}