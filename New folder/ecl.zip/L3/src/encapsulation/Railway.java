package encapsulation;

import java.util.Scanner;

public class Railway{
	public static void main(String[] args){
		Scanner scan=new Scanner(System.in);
		RailwayBook n=new RailwayBook();
		int choose=0;
		do{
			System.out.println("1>Booking\n2>Print\n3>Cancel");
				choose=scan.nextInt();
			if(choose==1)
				n.BookingTicket();
			else if(choose==2)
				n.Print();
			else if(choose==3)
				n.CancelTicket();
		}while(choose!=0);
	}
}
interface Reservation{
	public void Print();
}
interface Booking extends Reservation{
	public void BookingTicket();
}
interface Cancel{
	public void CancelTicket();
}
class RailwayBook implements Cancel,Booking{
	private Customer c[]=new Customer[10];
	int pnr=1234,cuscount=0,LB=2,UB=2,MB=2,RAC=2,WL=2,totalBerth=LB+UB+MB;
	Scanner scan=new Scanner(System.in);
	final public void BookingTicket(){
//		System.out.println("Cuscount: "+cuscount+"WL: "+WL);
		System.out.println("Enter ticket count: ");
		int n=scan.nextInt();
		for(int j=cuscount;j<n+cuscount;j++){
			System.out.println("Enter the name: ");
			String name=scan.next();
			System.out.println("Enter Gender: ");
			char gen=scan.next().charAt(0);
			System.out.println("Enter the age: ");
			int age=scan.nextInt();
			for(int i=0;i<c.length;i++) {
				if(c[i]==null||c[i].getName()==null) {
					if(LB!=0||UB!=0||MB!=0) {
						if(age>=50&&LB!=0){
							c[i]=new Customer(name,age,gen,"LB",pnr,i+1);
							LB--;
						}
						else{
							System.out.println("1>UB\n2>MB\n3>LB");
							int ber=scan.nextInt();
							switch(ber){
							case 1:
								if(UB!=0) {
									c[i]=new Customer(name,age,gen,"UB",pnr,i+1);
									UB--;
									break;
								}
							case 2:
								if(MB!=0) {
									c[i]=new Customer(name,age,gen,"MB",pnr,i+1);
									MB--;
									break;
								}
							case 3:
								if(LB!=0) {
									c[i]=new Customer(name,age,gen,"LB",pnr,i+1);
									LB--;
								}
								else if(MB!=0) {
									c[i]=new Customer(name,age,gen,"MB",pnr,i+1);
									MB--;
								}
								else if(UB!=0) {
									c[i]=new Customer(name,age,gen,"UB",pnr,i+1);
									UB--;
								}
							}
						}
					}
					else if(RAC!=0) {
						c[i]=new Customer(name,age,gen,"RAC",pnr);
						RAC--;
					}
					else if(WL!=0) {
						c[i]=new Customer(name, age, gen, "WL",pnr);
						WL--;
					}
					
					break;
				}
			}
		}
		pnr++;
		cuscount+=n;
	}
	final public void CancelTicket(){
		System.out.println("Enter the pnr: ");
		int refPnr=scan.nextInt();
		System.out.println("Enter th seat No:");
		int seat=scan.nextInt();
		for(int i=0;i<c.length;i++){
			//System.out.println(c[i].getName());
			if(c[i]!=null&&c[i].getPnr()==refPnr&&c[i].getSeatNo()==seat) {
				System.out.println(c[i]+"\n1>Delete");
				int del=scan.nextInt();
				if(del==1){
					if(c[totalBerth]!=null) {
					c[i].setName(c[totalBerth].getName());
					c[i].setAge(c[totalBerth].getAge());
					c[i].setGender(c[totalBerth].getGender());
					c[i].setPnr(c[totalBerth].getPnr());
					Swap(totalBerth);
					WL++;
					cuscount--;
					}
					else {
						c[i].setName(null);
						c[i].setAge(0);
						c[i].setGender(' ');
						c[i].setPnr(0);
						if(c[i].getBerth()=="UB") {
							UB--;
						}
						else if(c[i].getBerth()=="MB") {
							MB--;
						}
						else if(c[i].getBerth()=="LB") {
							LB--;
						}
						//WL++;
						cuscount--;
					}
				}
				break;
			}
		}
	}
	final public void Swap(int j) {
		if(j==c.length-1||c[j]==null) {
			c[j]=null;
			return;
		}
		c[j].setName(c[j+1].getName());
		c[j].setAge(c[j+1].getAge());
		c[j].setGender(c[j+1].getGender());
		c[j].setPnr(c[j+1].getPnr());
		j++;
		Swap(j);
	}
	final public void Print(){
		System.out.println("Enter the Pnr No: ");
		int EnPnr=scan.nextInt();
		for(int i=0;i<c.length;i++){
			if(c[i]!=null&&c[i].getPnr()==EnPnr)
			System.out.println(c[i]);
		}
	}
}
class Customer{
	private String name;
	private int age;
	private char Gender;
	private String Berth;
	private int pnr;
	private int seatNo;
	
	public String getBerth() {
		return Berth;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public char getGender() {
		return Gender;
	}
	public void setGender(char gender) {
		Gender = gender;
	}
	public int getPnr() {
		return pnr;
	}
	public void setPnr(int pnr) {
		this.pnr = pnr;
	}
	public int getSeatNo() {
		return seatNo;
	}
	public void setSeatNo(int seatNo) {
		this.seatNo = seatNo;
	}
	public Customer(String name,int age,char Gender,String Berth,int pnr) {
		this.name=name;
		this.age=age;
		this.Gender=Gender;
		this.Berth=Berth;
		this.pnr=pnr;
	}
	public Customer(String name,int age,char Gender,String Berth,int pnr,int seatNo){
		this.name=name;
		this.age=age;
		this.Gender=Gender;
		this.Berth=Berth;
		this.pnr=pnr;
		this.seatNo=seatNo;
	}
	public String toString() {
		return "Name: "+name+" Age: "+age+" Gender: "+Gender+" Berth: "+Berth+" PNR No: "+pnr+" Seat No: "+seatNo;
	}
}