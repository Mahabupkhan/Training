package encapsulation;

public class Exe3 {
public static void main(String[] args) {
	Animal a=new Wolf();
	a.roam();
	Animal[] an=new Animal[5];
	Animal[0]=
}
}
class Animal{
	public void roam() {
		System.out.println("Animal roaming");
	}
}
class Canine extends Animal{
	public void roam() {
		System.out.println("Canine roaming");
	}
}
class Wolf extends Canine{
	public void roam() {
		super.roam();
		System.out.println("Wolf roaming");
	}
}