package encapsulation;

import java.util.ArrayList;
import java.util.Arrays;

public class ArraylistDemo {
public static void main(String[] args) {
	ArrayList<Emp> arr=new ArrayList<>(Arrays.asList(new Emp(1,"mabu"),new Emp(2,"ashath")));
	for(int i=0;i<arr.size();i++)
		System.out.println(arr.get(i));
	ArrayList arr1=new ArrayList(5);
	arr1.add(1);
	arr1.add(1);
	arr1.add(1);
	arr1.add(1);
	arr1.add(1);
	arr1.add(1);
	for(int i=0;i<arr1.size();i++)
		System.out.println(arr1.get(i));
}
}
class Emp{
	int id;
	String name;
	Emp(int id,String name){
		this.id=id;
		this.name=name;
	}
	public String toString() {
		return id+" "+name;
	}
}