package encapsulation;

public class Cons {
public static void main(String[] args) {
	Cl c=new Cl();
	c.met();
	A.V v=new A.V();
	v.met();
}
}
interface A{
	int a=10;
	public void met();
	class V{
		void met() {
			System.out.println("Inner class");
		}
	}
}
interface B{
	int a=12;
	
}
class Cl implements A,B{
	public void met() {
		System.out.println(A.a+B.a);
	}
	public void met2() {
		
	}
}