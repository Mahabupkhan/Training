package encapsulation;

public class Exe2 {
public static void main(String[] args) {
	V e=new V();
	e.met();
	//e.print();
	ex x=new ex();
	x.met();
	//x.print();
	x.i=20;
	e.met1();
	System.out.println(x.i);
}
}
class ex{
	int i=10;
	static int j=20;
	public void met() {
		i=i+10;
		j=j+10;
	}
	native public void print();
}
class ex2 extends ex{
	public void met() {
		
	}
}
class V extends ex2{
	void met1() {
		System.out.println(i);
	}
}