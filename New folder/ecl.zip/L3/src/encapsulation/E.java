package encapsulation;

public class E {
public static void main(String[] args) {
	String str="hii";
	str=str+"hi";
}
}
