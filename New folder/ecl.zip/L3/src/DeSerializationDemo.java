import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

public class DeSerializationDemo {
public static void main(String[] args) throws Exception{
	//Student s=null;
	ArrayList<Student> std=new ArrayList<Student>();
	
	try {
		FileInputStream filein=new FileInputStream("D:\\Students.txt");
		ObjectInputStream in=new ObjectInputStream(filein);
		//System.out.println(in.available());
		for(int i=0;i<2;i++) {
			//System.out.println((Student)in.readObject());
		std.add((Student) in.readObject());
		}
		in.close();
		filein.close();
	}
	catch(Exception e) {
		e.printStackTrace();
	}
	System.out.println("Name\tRoll");
	
		for(int i=0;i<std.size();i++)
			System.out.println(std.get(i));
	
	
}
}
