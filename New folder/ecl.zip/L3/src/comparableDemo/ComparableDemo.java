package comparableDemo;

import java.util.Arrays;

public class ComparableDemo {
public static void main(String[] args) {
	Student s1=new Student("Suthish",21);
	Student s2=new Student("mabu",1);
	Student s3=new Student("jameel",19);
	Student s4=new Student("aadhil",31);
	Student s5=new Student("anas",25);
	Student[] std= {s1,s2,s3,s4,s5};
	Arrays.sort(std);
	for(int i=0;i<std.length;i++)
		System.out.println(std[i]);
	
}
}
class Student implements Comparable{
	String name;
	int id;
	Student(String name,int id){
		this.name=name;
		this.id=id;
	}
	@Override
	public int compareTo(Object o) {
		Student s=(Student)o;
		if(this.id<s.id) return 1;
		else if(this.id>s.id) return -1;
		else
		return 0;
	}
	public String toString() {
		return name+"  "+id;
	}
}