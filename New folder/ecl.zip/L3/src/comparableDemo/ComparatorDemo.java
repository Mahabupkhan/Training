package comparableDemo;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

public class ComparatorDemo {
	public static void main(String[] args) {
		System.out.println("Enter String array Size : ");
		Scanner scan = new Scanner(System.in);
		int size = scan.nextInt();
		String[] s = new String[size];
		for (int i = 0; i < size; i++)
			s[i] = scan.next();
		Comparator comp=new MyComparator();
		Arrays.sort(s,comp);
		for(String d:s)
			System.out.println(d+"  ");
	}
}

class MyComparator implements Comparator {

	@Override
	public int compare(Object o1, Object o2) {
		String s1 = (String) o1;
		String s2 = (String) o2;
		if(s1.length()>s2.length())
			return -1;
		else if(s1.length()<s2.length())
			return 1;
		else
			return 0;
	}

}
