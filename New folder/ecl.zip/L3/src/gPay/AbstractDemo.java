package gPay;

public class AbstractDemo {
public static void main(String[] args) {
	Car c1=new Bmw(8,240,new Engine(5000,200));
	Car c2=new Lambo(9,390,new Engine(7500,220));
	c1.putTheKey();
	c2.putTheKey();
}
}
class Engine{
	int cc;
	int hp;
	Engine(int cc,int hp){
		this.cc=cc;
		this.hp=hp;
	}
}
abstract class Car{
	int gear;
	int topSpeed;
	Engine e;
	abstract void startEngine();
	abstract void startTheCar();
	abstract void attainTopSpeed();
	abstract void putTheKey(); 
}
class Bmw extends Car{
	Bmw(int gear,int topSpeed,Engine e){
		this.gear=gear;
		this.topSpeed=topSpeed;
		this.e=e;
	}
	@Override
	void attainTopSpeed() {
		System.out.println("Reached top speed "+topSpeed+" km/hr");
	}
	@Override
	void startEngine() {
			
	}
	@Override
	void startTheCar() {
		System.out.println("Bmw car started....");
	}
	@Override
	void putTheKey() {
		startEngine();
		startTheCar();
		attainTopSpeed();
	}
}
class Lambo extends Car{
	
	Lambo(int gear,int topSpeed,Engine e){
		this.gear=gear;
		this.topSpeed=topSpeed;
		this.e=e;
	}
	@Override
	void startEngine() {
		System.out.println(e.cc+" CC "+e.hp+" hp Engine started....");
	}

	@Override
	void startTheCar() {
		System.out.println("Lambo car started....");
	}

	@Override
	void attainTopSpeed() {
		System.out.println("Reached top speed "+topSpeed+" km/hr");
	}
	void putTheKey() {
		startEngine();
		startTheCar();
		attainTopSpeed();
	}
	
}