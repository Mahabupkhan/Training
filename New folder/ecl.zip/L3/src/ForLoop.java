
public class ForLoop {
public static void main(String[] args) {
	int i=0;
	for(i=0;i<10;) {
		i++;
		if(i==0)
			break;
	}
	System.out.println(i);
}
}
