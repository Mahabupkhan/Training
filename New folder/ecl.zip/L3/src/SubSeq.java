import java.util.Scanner;

public class SubSeq {
public static void main(String[] args) {
	Scanner scan=new Scanner(System.in);
	char[] ch=scan.next().toCharArray();
	seq(0,"",ch);
}
public static void seq(int index,String un,char[] a) {
	if(index==a.length) {
		System.out.println(un);
		return;
	}
	seq(index+1,un+a[index],a);
	seq(index+1,un,a);
}
}
