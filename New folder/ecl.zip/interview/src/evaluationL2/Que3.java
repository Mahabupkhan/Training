package evaluationL2;

import java.util.Scanner;

public class Que3 {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter no of days to calculate Fine Amount : ");
		int days=scan.nextInt();
		System.out.println("Fine Amount is : "+findFine(days));
	}
	public static double findFine(int days) {
		double fines[];
		if(days<=7) return 0;
		else {
			int extraDays=days-7;
			double fine=0;
			fines=new double[extraDays];
			if(days>=15) {
				fine=fine+((days/15)*5);
			}
			int index=extraDays-1;
			while(extraDays>0) {
				if(extraDays<=3) {
					fine+=2.50;
				}
				else if(extraDays>3 && extraDays<=7) {
					fine+=5.75;
				}
				else {
					fine+=8.00;
				}
				fines[index--]=fine;
				extraDays--;
			}
			int dayForArray=8;
			for(int i=fines.length-1;i>=0;i--) {
				System.out.println("Total Fine till day "+dayForArray+" is : "+fines[i]);
				dayForArray++;
			}
			return fine;
		}
			
	}
}
