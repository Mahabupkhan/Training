package evaluationL2;

import java.util.Scanner;

public class Que1 {
//	public static void main(String[] args) {
//		Scanner scan=new Scanner(System.in);
//		System.out.print("Enter the number : ");
//		int n=scan.nextInt();
//	}
	
	public static void main(Integer n) {
		String num=n.toString();
		Integer answer=0;
		for(int i=num.length()-1;i>=0;i--) {
			String s="";
			if(i%2==0) {
			for(int j=num.length()-1;j>=i;j=j-2) {
					s+=num.charAt(j);	
			}
			answer+=Integer.valueOf(s);
			}
			
		}
		System.out.println("Answer is : "+answer);
	}
	
}
