package evaluationL2;

import java.util.Scanner;

public class Que4 {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the String : ");
		String str=scan.next();
		revSubString(str);
	}
	public static void revSubString(String s) {
		char[] c=s.toCharArray();
		for(int i=0;i<c.length;i++) {
			if(c[i]=='a' || c[i]=='e' || c[i]=='i' || c[i]=='o' || c[i]=='u') {
				char[] sub=new char[i+1];
				int k=0;
				for(int j=0;j<=i;j++) sub[k++]=c[j];
				sub=reverse(sub);
				k=0;
				for(int j=0;j<sub.length;i++)
					c[k++]=sub[i];		
				}
		}
		for(int i=0;i<c.length;i++)
			System.out.print(c[i]+"");
	}
	public static char[] reverse(char[] c) {
		char[] r=c;
		int j=0;
		for(int i=c.length-1;i>=0;i--) {
			c[j++]=r[i];	
		}
		for(int i=0;i<c.length;i++)
			System.out.print(c[i]+"");
		System.out.println();
		return c;
	}
}
