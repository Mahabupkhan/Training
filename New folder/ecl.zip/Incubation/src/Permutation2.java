import java.util.Scanner;

public class Permutation2 {
public static void main(String[] args) {
	Scanner scan=new Scanner(System.in);
	System.out.println("Enter the string : ");
	char[] str=scan.next().toCharArray();
	permutate(str,0,str.length-1);
	System.out.println(count);
}
static int count=0;
public static void permutate(char[] str,int l,int r) {
	if(l==r) {
		count++;
		for(int i=0;i<str.length;i++)
			System.out.print(str[i]);
		System.out.println();
		return;
	}
	for(int i=l;i<=r;i++) {
		swap(str,i,l);
		permutate(str,l+1,r);
		swap(str,i,l);
	}
}
public static void swap(char[] str,int i,int j) {
	char temp=str[i];
	str[i]=str[j];
	str[j]=temp;
}
}
