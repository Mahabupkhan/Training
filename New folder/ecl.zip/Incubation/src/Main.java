
public class Main {
public static void main(String[] args) {
	args[0]="hii";
	System.out.println(args[0]);
}
}
