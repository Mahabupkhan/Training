package busReservation;


import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;
class Deserialize{
	public static void main(String[] args){
		dodeSerialize();
	}
	public static void dodeSerialize(){
		ArrayList<Passenger> arr=new ArrayList<Passenger>();
		try{
			FileInputStream fi=new FileInputStream("C:\\Users\\Administrator\\Desktop\\Java\\ContinuosTask\\04 Jan\\PassDetail.txt");
			ObjectInputStream oi=new ObjectInputStream(fi);
			for(int i=0;i<3;i++){
				arr.add((Passenger) oi.readObject());
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			System.out.println("Name\tAge\tGender\tphno\tMail\tPickup\tDrop\tSeatNo");
			for(int i=0;i<arr.size();i++)
				System.out.println(arr.get(i));
		}
	}
	
}
