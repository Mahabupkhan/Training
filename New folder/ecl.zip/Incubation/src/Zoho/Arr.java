 import java.util.Scanner;
 import java.util.ArrayList;
 class Hospital{
	 public static void main(String[] args){
		 Patient p=new Patient();
		 p.patientEntry();
	 }
 }
 class Patient{
	 Scanner scan=new Scanner(System.in);
	 ArrayList<Integer> Id=new ArrayList<Integer>();
	 ArrayList<String> name=new ArrayList<String>();
	 ArrayList<Float> InTime=new ArrayList<Float>();
	 ArrayList<Float> OutTime=new ArrayList<Float>();
	 ArrayList<Float> MF1=new ArrayList<Float>();
	 ArrayList<Float> MF2=new ArrayList<Float>();
	 ArrayList<String> Complaint=new ArrayList<String>();
	 ArrayList<Float> WaitTime=new ArrayList<Float>();
	 ArrayList<Float> DocTime=new ArrayList<Float>();
	 int id=100;
	 int count=0;
	 
	 public void patientEntry(){
		 System.out.println("Enter Patient name : ");
		 String pname=scan.next();
		 name.add(pname);
		 //System.out.println(name);
		 if(checkdatabase(pname)){
			 interactMedProf1();
		 }
		 else{
			 System.out.println("Enter entry time : ");
			 float intime=scan.nextFloat();
			 InTime.add(intime);
			 
			 Id.add(id);
			 id++;
		 }
		 
		 
	 }
	 public boolean checkdatabase(String pname){
		 for(int i=0;i<name.size();i++){
			 if(pname.equals(name.get(i))){
				 return true;
			 }
			 else{
				 return false;
			 }
		 }
	 }
	 public void interactMedProf1(){
		 System.out.println("Enter patient complaint : ");
		 String pcomplaint=scan.nextLine();
		 Complaint.add(pcomplaint);
		 MF1.set(count,InTime.get(count)+0.05f);
		 
		 
		 
		 
	 }
	 
	 	 
 }
 