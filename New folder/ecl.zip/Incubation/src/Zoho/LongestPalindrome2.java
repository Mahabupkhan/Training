package Zoho;

import java.util.Scanner;

public class LongestPalindrome2 {
	static Scanner scan=new Scanner(System.in);
	public static void main(String[] args) {		 
		System.out.println("Enter the string : ");
		String str=scan.next();		
		char[] ch=str.toCharArray();
		int size=0;
		String result="";
		int flag=0;
		if(checkPali(str)) {
			System.out.println(str);
		}
		else {
		for(int i=0;i<str.length();i++) {
			String pass="";
			for(int j=str.length()-1;j>=0;j--) {
				
				if(str.charAt(i)==str.charAt(j)) {
					
					for(int k=i;k<j+1;k++) {
						
						  pass+=ch[k];
						 
					}
				 flag=0;
					if(checkPali(pass)) {
						
					if(pass.length()>size) {
						result=pass;
						size=result.length();
					}
					flag=1;
					break;
			
						 }
					if(flag==1) break;					
				}				
			}
		}		
		System.out.println(result);		
	}
	}
	public static  boolean checkPali(String str) {
		char[] ch=str.toCharArray();
		String reverse="";
		for(int i=ch.length-1;i>=0;i--) {
			reverse+=ch[i];
		}
		if(reverse.equals(str))
			return true;
		else
			return false;
		
	}
	
	
	
}
