package Zoho;

import java.util.*;
import java.util.stream.Stream;

public class ColDemo3 {
public static void main(String[] args) {
	//Rahul gandhi way
	List<String> rlist=Arrays.asList("ashath","ashath","afru","shamsu");
	List<Integer> ilist=Arrays.asList(1,2,3);
	Stream<Integer> stream2=ilist.stream();
	//Stream<String> stream=rlist.stream();
	stream2.forEach(System.out::println);
	System.out.println("-----------------");
	rlist.stream().distinct().forEach(System.out::println);
	System.out.println("-----------------");
	rlist.stream().forEachOrdered(System.out::println);
	System.out.println("-----------------");
	ilist.stream().forEach(System.out::println);
	System.out.println("-----------------");
	System.out.println(ilist.stream().count());
	System.out.println("-----------------");
	System.out.println(rlist.stream().count());
	System.out.println("-----------------");
	
	    
	
	
}

}
