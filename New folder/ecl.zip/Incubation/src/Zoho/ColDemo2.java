package Zoho;

//import java.util.ArrayList;
//import java.util.List;
import java.util.*;


public class ColDemo2 {
public static void main(String[] args) {
	List<String> gandhi=new ArrayList();
	gandhi.add("Afru");
	gandhi.add("vadakkooran");
	gandhi.add("vadakkooran 2");
	gandhi.add("Mahmood");
	List<Integer> no=new ArrayList();
	no.add(1);
	no.add(2);
	no.add(3);
	Iterator<String> iter=gandhi.iterator();
	Iterator<Integer> iter2=no.iterator();
	while(iter.hasNext()) {
		System.out.println(iter.next());
	}
	while(iter2.hasNext()) {
		System.out.println(iter2.next());
	}
}
}
