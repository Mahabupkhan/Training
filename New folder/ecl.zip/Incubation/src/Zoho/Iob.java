package Zoho;

import java.util.*;
import java.util.regex.*;

class Iob{
	public static void main(String[] args){
		Scanner scan=new Scanner(System.in);
		int uc;
		do{
			System.out.println("1.Admin\n2.Customer");
			 uc=scan.nextInt();
			switch(uc){
				case 1:
				Admin a=new Admin();
				a.logIn();
				break;
				case 2:
				Customer c=new Customer();
				c.signUp();
				break;
				
			}
		}while(uc<=2);
	}
}
class Admin{
	String username="Mabu";
	String pword="mabu@123";
	public void logIn(){
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter your name : ");
		String username1=scan.next();
		System.out.println("Enter password : ");
		String pword1=scan.next();
		
		if(username.equals(username1) && pword.equals(pword1)){
			System.out.println("Welcome Mabu !!!");
			System.out.println("1.View Details\n2.Exit");
			int uc=scan.nextInt();
			switch(uc){
				case 1:
				case 2:
			}
		}
		else{
			System.out.println("Wrong password or username !!!");
			Admin a=new Admin();
			a.logIn();
		}
	}
}
class Customer{
	Scanner scan=new Scanner(System.in);
	String cid="";
	String pword="";
	int pin;
	int giftcardno=932105;
	int accbalance=10000;
	int giftcardbalance=500;
	int reward;
	int purchase;
	int tamount;
	public void signUp(){
		//Scanner scan=new Scanner(System.in);
		
		
		System.out.println("Enter your name : ");
		cid=scan.next();
		System.out.println("Enter password : ");
		pword=scan.next();
		String s="^.*(?=.{8,})(?=..*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=]).*$";
		Pattern p=Pattern.compile(s);
		Matcher m=p.matcher(pword);
		boolean b=m.matches();  
		if(b){
		System.out.println("Do you want to sign in ? \n1.Yes\n2.No");
		int uc=scan.nextInt();
		switch(uc){
			case 1:
			//Customer c=new Customer();
			signIn();
			break;
			case 2:
			System.out.println("Thank you !!!");
			break;
		}
		}
		else{
			System.out.println("Enter atleast one lowercase and uppercase and one special character with lengthof 6");
			signUp();
		}
	}
	public void signIn(){
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter your name : ");
		String uname=scan.next();
		System.out.println("Enter password : ");
		String pword1=scan.next();
			if(uname.equals(cid) && pword1.equals(pword)){
				System.out.println("Welcome "+cid);		
				customerChoice();
			}
			else{
				System.out.println("Wrong password or username !!!\nSignIn again...");
				signIn();
			}
		
		
	}
	public void customerChoice(){
		
		Customer c=new Customer();
		int uc;
		do{
			System.out.println("1.Create Gift Card\n2.TopUp\n3.Transaction History\n4.Block\n5.Logout\n6.Purchase\n7.Redeem points\n8.Doing Multiple gift cards");
			 uc=scan.nextInt();
			switch(uc){
				case 1 : 
				c.createGift();
				break;
				case 2:
				c.doTopUp();
				break;
				case 3: 
				c.viewHistory();
				break;
				case 4:
				c.Block();
				break;
				case 5:
				c.doLogout();
				break;
				case 6:
				c.doPurchase();
				break;
				case 7:
				c.RedeemReward();
				break;
				default:
				System.out.println("Wrong choice !!!");
				customerChoice();
				
				
			}
		}while(uc<=7);
		
	}
	public void createGift(){
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter 4 digit pin : ");
		this.pin=scan.nextInt();
		System.out.println("Re-enter you pin : ");
		int pin1=scan.nextInt();
		if(pin==pin1){
		
		System.out.println("Giftcard created successfully...\nYour Giftcard no : "+giftcardno);
				}
		else{
			System.out.println("Pin mismatch !!!\nCreate Again....");
			createGift();
		}
		
	}
	public void doTopUp(){
		Scanner scan=new Scanner(System.in);
		System.out.println("your account balance is : "+accbalance);
		System.out.println("How much do you want to TopUp ?");
		int tamount=scan.nextInt();
		accbalance=accbalance-tamount;
		giftcardbalance=giftcardbalance+tamount;
		System.out.println("TopUp is successfully done....");
		
		
	}
	
	public void viewHistory(){
		System.out.println("Available account balance : "+accbalance);
		System.out.println("Gift card balance : "+giftcardbalance);
		System.out.println("Reward : "+this.reward+" points");
		
	}
	public void Block(){
		
	}
	public void doLogout(){
		System.out.println("Logged out successfully...");
		Iob.main(null);
	}
	public void doPurchase(){
		System.out.println("Enter Gift card no : ");
		int id=scan.nextInt();
		System.out.println("Enter pin : ");
		int pw=scan.nextInt();
		if(id==giftcardno && pw==pin){
			System.out.println("How much you want to purchase : ");
			purchase=scan.nextInt();
			
			giftcardbalance=giftcardbalance-purchase;
			System.out.println("Available gift card balance is : "+(giftcardbalance));
			//RedeemReward();
			
		}
		else{
			System.out.println("Wrong password or user name !!!");
			doPurchase();
		}
	}
	public void RedeemReward(){
		this.reward+=purchase/100;
		System.out.println("Redeemed Successfully....");
	}
}
