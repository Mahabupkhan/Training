package Zoho.copy;

//import java.util.ArrayList;
//import java.util.List;
import java.util.*;


public class ColDemo2 {
//public static void main(String[] args) {
//	List<String> gandhi=new ArrayList();
//	gandhi.add("Afru");
//	gandhi.add("vadakkooran");
//	gandhi.add("vadakkooran 2");
//	gandhi.add("Mahmood");
//	List<Integer> no=new ArrayList();
//	no.add(1);
//	no.add(2);
//	no.add(3);
//	Iterator<String> iter=gandhi.iterator();
//	Iterator<Integer> iter2=no.iterator();
//	while(iter.hasNext()) {
//		System.out.println(iter.next());
//	}
//	while(iter2.hasNext()) {
//		System.out.println(iter2.next());
//	}
//}
	public static void main(String[] args) {
	 int arr[]= {0};
	 Integer i=new Integer(10);
		Demo(arr);
		//System.out.println(arr[0]);
		Demo2(i);
		System.out.println(i);
	}
	public static void Demo(int arr[]) {
		arr[0]=10;
	}
	public static void Demo2(Integer i) {
		i=10;
	}
}
