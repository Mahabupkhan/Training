import java.util.*;

public class BinaryToGrayCode {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the Binary Number");
		char ch[]=scan.next().toCharArray();
		ConvertGrayCode(ch,0);
	}
	public static void ConvertGrayCode(char ch[],int i) {
		if(i==ch.length) {
			return;
		}
		else if(i==0) {
			System.out.print(ch[i]);
			//i++;
			ConvertGrayCode(ch,++i);
			return;
		}
		else if(ch[i]!=ch[i-1]) {
			System.out.print("1");
			//i++;
			ConvertGrayCode(ch,++i);
		}
		else {
			System.out.print("0");
			//i++;
			ConvertGrayCode(ch,++i);
		}
	}
}
