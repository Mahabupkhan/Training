package designPatterns;

import java.util.ArrayList;

public class BuilderPatternDemo {
public static void main(String[] args) {
	Passenger p=new Passenger.SetDetails().setAge(10).setName("mabu").setGender('M').build();
	System.out.println(p);
	String str="str";
    ArrayList arrayList=new ArrayList<>();
    arrayList.add("y");
    arrayList.clear();
    System.out.println(arrayList);
    System.out.println();;
}
}

class Passenger{
	private String name;
	private int age;
	private char gender;
	Passenger(){
		
	}
	Passenger(SetDetails p){
		this.name=p.name;
		this.age=p.age;
		this.gender=p.gender;
	}
	public String toString() {
		return name+"  "+age+"  "+gender;
	}
	static class SetDetails{
		private String name;
		private int age;
		private char gender;
		public SetDetails setName(String name) {
			this.name=name;
			return this;
		}
		public SetDetails setAge(int age) {
			this.age=age;
			return this;
		}
		public SetDetails setGender(char gender) {
			this.gender=gender;
			return this;
		}
		public Passenger build() {
			return new Passenger(this);
		}
	}
}
