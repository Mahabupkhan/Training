package designPatterns;



import java.util.Collections;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

import Task.main;

public class Demo2 {
	public static void main(String[] args) {
		Queue que=new LinkedList();
		que.add(1);
		que.add(2);
		que.add(3);
		System.out.println(que);
		List stack=new Stack();
		
	}
}
