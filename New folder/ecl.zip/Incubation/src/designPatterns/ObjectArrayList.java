package designPatterns;

import java.util.ArrayList;
import java.util.Scanner;

import Task.main;

public class ObjectArrayList {
	static ArrayList<Stud> studs=new ArrayList<Stud>();
	static Scanner scan=new Scanner(System.in);
public static void main(String[] args) {
	System.out.println("How many students u want to add?");
	int n=scan.nextInt();
	for(int i=0;i<n;i++) {
		addStud();
	}
	printStud();
	
}
static void addStud() {
	System.out.println("Enter name : ");
	String name=scan.next();
	System.out.println("Enter age : ");
	int age=scan.nextInt();
	studs.add(new Stud(name,age));
}
static void printStud() {
	System.out.println("Enter name to find ;");
	String name=scan.next();
	for(int i=0;i<studs.size();i++) {
		if(studs.get(i).name.equals(name)) {
			System.out.println(studs.get(i).age);
		}
	}
}
}
class Stud{
	String name;
	int age;
	Stud(String name,int age){
		this.name=name;
		this.age=age;
	}
	public String toString() {
		return name+"    "+age;
	}
}