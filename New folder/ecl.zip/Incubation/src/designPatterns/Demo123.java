package designPatterns;

import java.util.Scanner;

public class Demo123{
public static void main(String[] args) {
	Scanner scan=new Scanner(System.in);
	System.out.println("Enter firstname : ");
	String fname=scan.next();
	System.out.println("Enter lastname : ");
	String lname=scan.next();
	System.out.println("Enter age : ");
	int age=scan.nextInt();
	Student s=new Student(new Name(fname,lname),age);
	System.out.println(s.name.lname);
	
}
}
class Student{
	Name name;
	int age;
	Student(Name name,int age){
		this.name=name;
		this.age=age;
	}
	public void print() {
		System.out.println()
	}
}
class Name{
	String fname;
	String lname;
	Name(String fname,String lname){
		this.fname=fname;
		this.lname=lname;
	}
}