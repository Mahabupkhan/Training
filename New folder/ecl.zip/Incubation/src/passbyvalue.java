import java.util.ArrayList;

public class passbyvalue {
public static void main(String[] args) {
	ArrayList<ArrayList> all=new ArrayList<ArrayList>();
	ArrayList a=new ArrayList();
	ArrayList b=new ArrayList();
	a.add(1);
	a.add(1);
	a.add(1);
	a.add(1);
	a.add(1);
	b.add(1);
	b.add(1);
	b.add(1);
	b.add(1);
	b.add(1);
	b.add(1);
	all.add(a);
	all.add(b);
	System.out.println(all);
	a.add(2);
	System.out.println(all);
	
	
}
}