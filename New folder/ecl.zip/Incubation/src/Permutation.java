//import java.util.Arrays;
import java.util.Scanner;
import java.util.Arrays;
public class Permutation {
	static int count=0;
	static int countswap=0;
	public static void main(String[] args){
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the string : ");
		char str[]=s.nextLine().toCharArray();
		//s.close();
		per(str,0,str.length-1);
		System.out.println(count);
		System.out.println("swap : "+countswap);
		Integer i;
	}
	public static void per(char str[],int l,int r){
		count++;
		if(l==r){
			//count++;
			for(int i=0;i<str.length;i++)
				System.out.print(str[i]);
			System.out.println();
			return;
		}
		for(int i=l;i<=r;i++){
			swap(str,i,l);
			//System.out.println(str);
			per(str,l+1,r);
			swap(str,i,l);
			//System.out.println(str);
		}
	}
	public static void swap(char str[],int i,int j){
		countswap++;
		char temp=str[i];
		str[i]=str[j];
		str[j]=temp;
	}
}
