import java.util.Scanner;

public class SelectSort {
public static void main(String[] args) {
	Scanner scan=new Scanner(System.in);
	System.out.println("Enter array size : ");
	int size=scan.nextInt();
	int[] arr=new int[size];
	for(int i=0;i<size;i++)
		arr[i]=scan.nextInt();
	 for (int i = 0; i < arr.length; i+=2)  
     {  
         int index = i;  
         for (int j = i + 1; j < arr.length; j++){  
             if (arr[j] < arr[index]){  
                 index = j; 
             }  
         }  
         int smallerNumber = arr[index];   
         arr[index] = arr[i];  
         arr[i] = smallerNumber;  
        
     }
	 for (int k = 0; k < arr.length ; k++)  
		 System.out.print(arr[k]+" ");
     System.out.println();
	 
}
}
