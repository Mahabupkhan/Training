package fileHandling;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;

import Task.main;

public class Demo1 {
public static void main(String[] args) throws IOException {
	File file=new File("C:\\Users\\Administrator\\Desktop\\crm-1.pdf");
	try {
		System.out.println(file.createNewFile());
	} catch (Exception e) {
		e.printStackTrace();
	}
	FileWriter fw=new FileWriter(file);
	BufferedWriter bw=new BufferedWriter(fw);
	bw.write("This is my first pdf writing....");
	bw.close();
	String str="";
	FileReader fr=new FileReader(file);
	BufferedReader br=new BufferedReader(fr);
	String sr=br.readLine();
	while(sr!=null) {
		String k[]=sr.split(" ");
		System.out.println(Arrays.toString(k));
		sr=br.readLine();
	}
}
}
