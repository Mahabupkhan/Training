package fileHandling;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.Stack;

public class Demo2 {
	static Stack<Det> st=new Stack<Det>();
	static Scanner scan=new Scanner(System.in);
public static void main(String[] args) throws IOException {
	System.out.println("how many details u want to add?");
	int n=scan.nextInt();
	for(int i=0;i<n;i++) {
		addDet();
	}
	writeInFile();
}
public static void  addDet() {
	System.out.println("Name : ");
	String name=scan.next();
	System.out.println("Age : ");
	int age=scan.nextInt();
	System.out.println("Height : ");
	int h=scan.nextInt();
	st.add(new Det(name,age,h));	
}
public static void writeInFile() throws IOException {
	File f=new File("C:\\Users\\Administrator\\Desktop\\Demo4.txt");
	boolean b=false;
	try {
		if(f.createNewFile()) {
			b=true;
		}
	} catch (IOException e) {
		e.printStackTrace();
	}
	FileWriter fw=new FileWriter(f,true);
	BufferedWriter bw=new BufferedWriter(fw);
	if(b) {
		bw.write("Name\tAge\theight");
		bw.newLine();
	}
	for(int i=0;i<st.size();i++) {
		bw.write(st.get(i).toString());
		bw.newLine();
		
	}
	bw.close();
	
	System.out.println("Written in file...");
	
}

}
class Det{
	String name;
	int age;
	int height;
	public Det(String name,int age,int height){
	this.name=name;
	this.age=age;
	this.height=height;
	}
	public String toString() {
		return name+"\t"+age+"\t"+height;
	}
}