import java.util.Scanner;

public class RomanNumber {
public static void main(String[] args) {
	Scanner scan=new Scanner(System.in);
	String str=scan.next();
	int temp1=0;
	int temp2=0;
	int sum=0;
	for(int i=str.length()-1;i>=0;) {
		if(i!=0)
		temp1=convertInt(str.charAt(i--));
		if(i==0) {
		temp2=convertInt(str.charAt(i));
		i=-1;
		temp1=0;
		}
		if(temp1<=temp2)
			sum+=temp1+temp2;
		else if(temp1>temp2)
			sum+=temp1-temp2;
	}
	System.out.println(sum);
	
	
}
public static int convertInt(char ch) {
	
	switch(ch) {
	case 'I':
		return 1;
	case 'V':
		return 5;
	case 'X':
		return 10;
	case 'L':
		return 50;
	case 'C':
		return 100;
	case 'D':
		return 500;
	case 'M':
		return 1000;
		default:
			return 0;
	}
}
}

