 import java.util.ArrayList;
import java.util.Scanner;

import java.util.Iterator;

public class Training {
public static void main(String[] args) {
	int uc;
	Scanner scan=new Scanner(System.in);
	
	do {
		System.out.println("1.add\n2.view\n3.Search");
		uc=scan.nextInt();
		switch(uc) {
		case 1:
			Emp.addEmp();
			break;
		case 2:
			Emp.view();
			break;
		case 3:
			Emp.search();
			break;
		}
	}while(uc<4);
	
}
}
class Emp{
	private static ArrayList<Emp> a=new ArrayList<Emp>();
	 private  String name;
	 private  int age;
	Emp(String name,int age){
		this.name=name;
		this.age=age;
	}
	public Emp() {
		// TODO Auto-generated constructor stub
	}
	public String toString() {
		return name+" "+age;
	}
	public  String getName() {
		return name;
	}
	public static void addEmp() {
		Scanner scan=new Scanner(System.in);
		System.out.println("name : ");
		String name=scan.next();
		System.out.println("age : ");
		int age=scan.nextInt();
		a.add(new Emp(name,age));
	}
	public static void view() {
		Iterator<Emp> i=a.iterator();
		while(i.hasNext()) {		
			System.out.println(i.next());
		
		}
		//System.out.println(a);
	}
	public static void search() {
		Emp e=new Emp();
		Scanner scan=new Scanner(System.in);
		System.out.println("enter name to search : ");
		String name=scan.next();
		Iterator<Emp> i=a.iterator();
		boolean found=true;
		while(i.hasNext()) {		
			if(e.getName()==name)
				System.out.println(i);
				found=false;
		}
		if(!found)
			System.out.println("name not found");
	}
}
