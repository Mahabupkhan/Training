import java.util.*;
class Hospital2{
	public static void main(String[] args){
		Scanner scan=new Scanner(System.in);
		int uc;
		Patient2 p=new Patient2();
		do{
		System.out.println("1.View Details\n2.Patient Entry");
       		uc=scan.nextInt();
		switch(uc){
			case 1:	
				p.ViewDetails();
				break;
			case 2:
			p.patientEntry();
			break;
			default :
				System.out.println("Wrong choice !!!!");
				main(args);
				}
		}while(uc>0);
	}
}
class Patient2{
	Scanner scan=new Scanner(System.in);
	int[] Id=new int[10];
	String[] name=new String[10];
	float[] InTime=new float[10];
	float[] OutTime=new float[10];
	float[] DocTime=new float[10];
	float[] WaitTime=new float[10];
	float[] mf1=new float[10];
	float[] mf2=new float[10];
	float[] PharmTime=new float[10];
	String[] complaint=new String[10];
	int id=100;
	int count=0;
	
	public void patientEntry(){
		System.out.println("Enter Patient name : ");
		String pname=scan.next();
		if(checkdatabase(pname)){
			System.out.println("You already registered...");
			System.out.println("Enter entry time : ");
			InTime[count]=scan.nextFloat();
			interactMedProf1();
		}
		else{
			name[count]=pname;
			Id[count]=id;
			id++;
			System.out.println("Enter entry time : ");
			InTime[count]=scan.nextFloat();
			interactMedProf1();
			
		}
		
	}
	 public boolean checkdatabase(String pname){
		 boolean result=false;
		 for(int i=0;i<name.length;i++){
			 if(pname.equals(name[i])){
				 result=true;
			 }	
		 }
		 return result;
	 }
	  public void interactMedProf1(){
		 System.out.println("Enter patient complaint : ");
		 String pcomplaint=scan.next();
		 complaint[count]=pcomplaint;
		 mf1[count]=InTime[count]+0.05f;
		 interactMedProf2();
	  }
	   public void interactMedProf2(){
		 mf2[count]=mf1[count]+0.05f;
		 visitDoctor();
	 }
	 public void visitDoctor(){
		  System.out.println("Visiting Doctor.....");
		 System.out.println("Enter doctor timing : ");
		 int dtime=scan.nextInt();
		 float dtime2=dtime/100;
		 DocTime[count]=mf2[count]+dtime2;
	 }
	  public void visitPharm(){
		  System.out.println("Visiting Pharmacy....");
			PharmTime[count]=DocTime[count]+0.05f;
	  }
	  public void calOutTime(){
		  OutTime[count]=PharmTime[count];
		  count++;
	  }
	  public void ViewDetails(){
		  System.out.println("Patient ID\tDoctorTime\tOut Time\tWait Time");
		  for(int i=0;i<10;i++){
			  System.out.println(Id[i]+"\t\t"+DocTime[i]+"\t\t"+OutTime[i]+"\t\t"+WaitTime[i]);
		  }
	  }
	
	
	
}