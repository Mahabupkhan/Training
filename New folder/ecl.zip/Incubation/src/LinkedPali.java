import java.util.Scanner;

public class LinkedPali {
public static void main(String[] args) {
	Scanner scan=new Scanner(System.in);
	int size=scan.nextInt();
	int[] head=new int[size];
	for(int i=0;i<size;i++)
		head[i]=scan.nextInt();
	System.out.println(isPalindrome(head));
		
}
public static  boolean isPalindrome(int[] head) {
    boolean result=false;
    int j=head.length-1;
    for(int i=0;i<head.length;i++){
        if(head[i]==head[j--])
           result=true;
        else{
            result=false;
            break;
        }
    }
           return result;
    
}
}
