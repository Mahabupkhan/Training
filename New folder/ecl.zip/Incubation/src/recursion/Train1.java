package recursion;

public class Train1 {
public static void main(String[] args) {
	met1(10);
	System.out.println(sum);
}
static int sum=0;
public static void met1(int i) {
	if(i==0)
		return;
	else {
		met1(i-1);
		sum+=i;
			
	}
}
}
