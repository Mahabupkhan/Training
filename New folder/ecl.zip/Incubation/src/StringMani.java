class StringMani{
	public static void main(String[] args) {
		Animal a=new Animal("lion","Chicken");
		a.met();
		Animal t=new Animal(10,20);
		t.met();
	}
}
class Animal{
	public Animal(String string, String string2) {
		this.name=string;
		this.food=string2;
	}
	public Animal(int i, int j) {
		System.out.println(i+" : "+j);
	}
	String name;
	String food;
	void met() {
		System.out.println(name+" "+food);
	}
}
