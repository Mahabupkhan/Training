public class PojoClass {
public static void main(String[] args) {
	cl c=new cl();
	c.setclg("new college");
	System.out.println(c.geti()+"\n"+c.name+"\n"+c.clg);
}
}
class cl{
	private int i=100;
	 String name="mabu";
	 String clg;
	public int geti() {
		return i;
	}
	public void setclg(String clg) {
		this.clg=clg;
	}
}
