package L3;
import java.util.*;
public class HighwaysDepartment {
public static void main(String[] args) {
	Scanner scan=new Scanner(System.in );
	int uc;
	do {
	System.out.println("1.Book Travel\n2.View TollDeatails");
	 uc=scan.nextInt();
	if(uc==1) {
		Route R=new Route();
		R.collectInfo();
	}
	else if(uc==2) {
		
	}
	}while(uc!=1 || uc!=2);
	
}
}
class Route{
	int start;
	int end;
	int vtype;
	int vip;
	public void collectInfo() {
		Scanner scan=new Scanner(System.in);
		System.out.println("1.Chennai\n2.Vilupuram\n3.Trichy\n4.KanyaKumari\nEnter start and end : ");
		 start=scan.nextInt();
		 end=scan.nextInt();
		System.out.println("Enter vehicle Type : \n1.car\n2.Heavy Vehicle");
		 vtype=scan.nextInt();
		System.out.println("Are you a VIP customer ?\n1.Yes\n2.No");
		 vip=scan.nextInt();		
	}
	public void SetRoute() {
		if(start==1 && end==2) {
			Chennai chennai=new Chennai(vtype,vip);
			chennai.CollectMoney();
			Vilupuram vilu=new Vilupuram(vtype,vip);
			vilu.CollectMoney();
		}
	}
	
}
abstract class Vehicle {
	
}
class car extends Vehicle{
	
}
class Heavy extends Vehicle{
	
}
abstract class Customer{
	abstract void collectMoney();
	
}
class Vip extends Customer{
	@Override
	void collectMoney() {
		
		
	}
}
class Normal extends Customer{
	@Override
	void collectMoney() {
		
		
	}
	
}
abstract class TollPlaza{
	//int[] carfair= {100,150,0,200};
	//int[] lorryfair= {200,150,0,400};
	int[] noofcars= new int[4];
	int[] noofhvehicle=new int[4];
	int[] carfare=new int[4];
	int[] heavyfare=new int[4];
	String[] toll= {"Chennai  ","Vilupuram  ","Trichirapalli","kanyakumari"};
	
	
	abstract void CollectMoney();
	void TollDeatils() {
		for(int i=0;i<toll.length;i++) {
			System.out.println(toll[i]+"\t"+noofcars[i]+"\t"+noofhvehicle[i]);
		}
	}
	
	
}

	

class Chennai extends TollPlaza{
	int carfair=100;
	int heavyfair=200;
	int vtype;
	int vip;
	public Chennai(int vtype,int vip) {
		this.vtype=vtype;
		this.vip=vip;
	}
	@Override
	void CollectMoney() {
		//int money;
		if(vtype==1) {
			noofcars[0]++;
			if(vip==1)
			carfare[0]+=carfair;
			else
				carfare[0]+=(carfair/100)*20;
		}
		else if(vtype==2) {
			noofhvehicle[0]++;
			if(vip==1)
			heavyfare[0]+=heavyfair;
			else
				heavyfare[0]+=(heavyfair/100)*20;
		}
		
	}
	
}
class Vilupuram extends TollPlaza{
	int carfair=150;
	int heavyfair=300;
	int vtype;
	int vip;
	public Vilupuram(int vtype,int vip){
		this.vtype=vtype;
		this.vip=vip;
	}
@Override
	void CollectMoney() {
	if(vtype==1) {
		noofcars[1]++;
		if(vip==1)
		carfare[1]+=carfair;
		else
			carfare[1]+=(carfair/100)*20;
	}
	else if(vtype==2) {
		noofhvehicle[1]++;
		if(vip==1)
		heavyfare[1]+=heavyfair;
		else
			heavyfare[1]+=(heavyfair/100)*20;
	}
		
	}	
}
class Trichy extends TollPlaza{
	int carfair=0;
	int heavyfair=0;
	@Override
	void CollectMoney() {
		
	}
}
class KanyaKumari extends TollPlaza{
	int carfair=200;
	int heavyfair=400;
	@Override
	void CollectMoney() {
		
		
	}
}
