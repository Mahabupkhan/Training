import java.util.Scanner;

public class Trainining {
public static void main(String[] args) {
	Scanner scan=new Scanner(System.in);
	boy afru=new boy();
	int uc;
	do {
	System.out.println("Which book you want to read?");
	System.out.println("1.Tamil\n2.English\n3.Maths\n4.Science\n5.Social\n6.Exit");
	uc=scan.nextInt();
	Book b = null;
	
	switch(uc) {
	case 1:
		b=new TamilBook();
		break;
	case 2 :
		b=new EnglishBook();
		break;
	case 3:
		b=new MathsBook();
		break;
	case 4:
		b=new ScienceBook();
		break;
	case 5:
		b=new SocialBook();
		break;
	case 6:
		break;
	
	}
	afru.read(b);
	}while(uc!=6);
}
}
class boy{
	public void read(Book book) {
		book.show();
	}
}
abstract class Book{
	abstract public  void show();
}
class TamilBook extends Book{
	String content="Tamil is our mother tongue";
	public void show() {
		System.out.println(content);
	}
}
class EnglishBook extends Book{
	String content="English is just a tool for communication";
	public void show() {
		System.out.println(content);
	}
}
class MathsBook extends Book{
	String content="(a+b)^2 = a^2 + b^2 +2ab";
	public void show() {
		System.out.println(content);
	}
}
class ScienceBook extends Book{
	String content="Everything is science";
	public void show() {
		System.out.println(content);
	}
}
class SocialBook extends Book{
	String content="Hitler is very danger fellow";
	public void show() {
		System.out.println(content);
	}
}