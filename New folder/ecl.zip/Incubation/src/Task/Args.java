package Task;

public class Args {
public static void main(String[] args) {
	Mahmood2 m=new Mahmood2();
	Mahmood2 a=Mahmood2.getInstance();
	System.out.println(m.i);
	System.out.println(a.i);
	System.out.println(m.hashCode());
	System.out.println(a.hashCode());
}
}
class Mahmood2{
	int i=10;

	public static Mahmood2 getInstance() {
		// TODO Auto-generated method stub
		return new Mahmood2();
	}
}