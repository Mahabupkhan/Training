package Task;
import java.util.*;
import java.util.ArrayList;
import java.util.stream.Collectors;
import java.util.stream.Stream;
public class ColDemo2 {
	public static void main(String[] args) {
		//GANDHI WAY
		List<String> list=new ArrayList<String>();
		
		list.add("hello");
		list.add("hai");
		list.add("bai");
		list.add("hello");
		
		Iterator<String> iter=list.iterator();
//		while(iter.hasNext()) {
//			//System.out.println(iter.next());
//		}
		
		
		//RAHUL GANDHI WAY
		List<String> rlist=Arrays.asList("hello","hai","bai","hello");
		Stream<String> stream= rlist.stream();
		//stream.forEach(System.out::println);
	
		//rlist.stream().distinct().forEach(System.out::println);
		
		//rlist.stream().forEachOrdered(System.out::println);
		
		//rlist.stream().parallel().forEach(System.out::println);
		
		System.out.println("...........");
		//rlist.stream().parallel().forEachOrdered(System.out::println);
		
		//System.out.println(rlist.stream().count());
		
		//rlist.parallelStream().forEach(System.out::println);
		//rlist.parallelStream().forEachOrdered(System.out::println);
		
		//rlist.stream().findAny().of("bai").
		//ifPresentOrElse(System.out::println, new Logic()::met);
		
		List newlist=rlist.stream().
			filter((x)->{return x.equals("hello");}).
			collect(Collectors.toList());
		
		//System.out.println(newlist);
		//newlist.stream().forEach(System.out::println);
		
	    newlist=rlist.stream().
				filter((x)->{
					char c=x.charAt(0);
					if(c=='h') {
						return true;
					}
					else {
						return false;
					}
				}).
				collect(Collectors.toList());
			
			System.out.println(newlist);
			newlist.stream().forEach(System.out::println);
	}
}
class Logic{
	public void met() {
		System.out.println("some business logic...");
	}

}
