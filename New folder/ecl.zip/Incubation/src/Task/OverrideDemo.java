package Task;

import java.util.Scanner;

public class OverrideDemo {
public static void main(String[] args) {
	Animal a=new cat();
	a.eat();
	 dog d=new dog();
	d.eat();
	A b=new A("name",28);
}
}
class Animal{
	void eat() {
		System.out.println("Eat");
	}
}
class dog{
	void eat() {
		System.out.println("biscuit");
	}
}
class cat extends Animal{
	void eat() {
		System.out.println("Milk");
	}
}
