package Task;

public class Revision {
public static void main(String[] args) {
	Mahmood m=new Mahmood();
	m.value=100;
	//System.out.println(m.value);
	m=new Mahmood();
	//System.out.println(m.value);
//	System.out.println(m.i);
	m.i=10;
	//System.out.println(m.i);
	m.i=30;
	//System.out.println(m.i);
	m.value=500;
	//System.out.println(m.value);
	m.met1();
	
}
}
class Mahmood{
	static int value = 200;
	int i=20;
	 static void met1() {
		System.out.println("Met 1 called");
	}
}
