package Task;

public class main {
public static void main(String[] args) {
	byte b=(byte)256;
	System.out.println(b);
}
}
