package Task;

public class FinalEx {

public static void main(String[] args) {
	final int i =100;
	mahmood a=new mahmood();
	a.change();
	System.out.println(i);
	
}
}
class mahmood{
void change() {
	 int i=50;
}
}
