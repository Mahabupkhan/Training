package Task;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Coin_combination {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter array size : ");
		int size=scan.nextInt();
		int[] arr=new int[size];
		System.out.println("Enter array elements : ");
		for(int i=0;i<size;i++) {
			arr[i]=scan.nextInt();
		}
		System.out.println("Enter target : ");
		int target=scan.nextInt();
		List<List<Integer>> li=new ArrayList<List<Integer>>();
		findCombo(0,target,arr,li,new ArrayList());
		System.out.println(li);
		
	}
	public static void findCombo(int ind,int target,int[] arr,List<List<Integer>> ans,List<Integer> ds) {
		if(ind==arr.length) {
			if(target==0) {
				ans.add(new ArrayList(ds));
			}
			return;
		}
		if(arr[ind]<=target) {
			ds.add(arr[ind]);
			findCombo(ind,target-arr[ind],arr,ans,ds);
			ds.remove(ds.size()-1);
		}
		findCombo(ind+1,target,arr,ans,ds);
	}

}

