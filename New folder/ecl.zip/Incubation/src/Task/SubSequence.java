package Task;

import java.util.ArrayList;

public class SubSequence {
public static void main(String[] args) {
	int[] arr= {1,2,3};
	Subseq(0,arr,new ArrayList());
}
	public static void Subseq(int ind,int[] arr,ArrayList<Integer> al) {
		if(ind==arr.length) {
			System.out.println(al);
			return;
		}
		al.add(arr[ind]);
		Subseq(ind+1,arr,al);
		al.remove(al.size()-1);
		Subseq(ind+1,arr,al);
		
	}
}
