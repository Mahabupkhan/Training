package Task;

import java.util.ArrayList;

public class ArrayListDemo {
public static void main(String[] args) {
	ArrayList al=new ArrayList();
	System.out.println(al.size());
	
}
}
