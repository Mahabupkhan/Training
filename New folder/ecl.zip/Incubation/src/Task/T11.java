package Task;

public class T11 {
public static void main(String[] args) {
	int[] a= {1,5,7,9,10};
	int max=a[0];
	for(int i=0;i<a.length;i++) {
		if(max<a[i])
			max=a[i];
	}
	
}
}
