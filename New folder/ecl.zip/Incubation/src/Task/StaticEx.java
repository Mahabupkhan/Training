package Task;

public class StaticEx {
public static void main(String[] args) {
	staticmet();
	StaticEx a=new StaticEx();
	afru af=new afru();
	a.met();
	afru.ashath();
	af.shamsu();
	af=new afru();
	
}
static void staticmet() {
	System.out.println("Static met called....");
}
void met() {
	System.out.println("Normal met called....");
}
}
class afru{
	static void ashath() {
		System.out.println("Ashath met called....");
	}
	void shamsu() {
		System.out.println("Shamsu met called....");
	}
}