package Task;

public class InterFaceDemo {
public static void main(String[] args) {
	Ashath a=new Ashath();
	a.eat();
	a.run();
}
}

abstract class Afru{
	void met() {
		
	}
	abstract void met2();
}
interface inter{
	 void eat();
	 void run();
	 void sleep();
}
class Ashath implements inter2{
	@Override
	public void eat() {
		System.out.println("eating");
		
	}
	@Override
	public void run() {
		System.out.println("runing..");
	}@Override
	public void sleep() {
		System.out.println("sleep");
	}
	@Override
	public void code() {
		
		
	}@Override
	public void walk() {
		  
		
	}
}
interface inter2 extends inter{
	void walk();
	void code();
}
