package Task;

public class T6 {

	public static void main(String[] args) {
	Parent P=new Parent(6,"shamsu");
	P.print();
	}

}
class Parent{
	int n;
	String name1;
	Parent(int i,String name){
		n=i;
		name1=name;
	}
	void print() {
		System.out.println(n+" "+name1);
	}
}
