package Task;
import java.util.Scanner;
public class Reverse {
public static void main(String[] args) {
	Scanner scan=new Scanner(System.in);
	System.out.println("enter string : ");
	String str=scan.next();
	int count=0;
	int splcount=0;
	char[] splchar=new char[100];
	int n=0;
	for(int i=0;i<str.length();i++) {
		if(str.charAt(i)<97 && str.charAt(i)>90|| str.charAt(i)>122 || str.charAt(i)<65 )
			count++;
		else {
			splchar[n]=str.charAt(i);
			splcount++;
		}
	}

	//System.out.println(count+1);
	String[] array=new String[count+1];
	//System.out.println(array.length);
	//String reverse="";
	
	for(int k=0;k<array.length;k++)
		array[k]="";
		
		int i=0;
		for(int j=0;j<str.length();j++) {
			
			if(str.charAt(j)>=48 && str.charAt(j)<=57 && str.charAt(j)<65 ||str.charAt(j)>=96 && str.charAt(j)<=122 || str.charAt(j)>=65 && str.charAt(j)<=92) {
				array[i]+=str.charAt(j);
			}
			else 
				i++;
			
		
		}
	for(int m=count;m>=0;m--)
		if(array[m]!="")
		System.out.print(array[m]);
	
}
}
