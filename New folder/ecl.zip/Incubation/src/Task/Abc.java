package Task;

public class Abc {
public static void main(String[] args) {
	final int i=0;
	i=1;
}
}
