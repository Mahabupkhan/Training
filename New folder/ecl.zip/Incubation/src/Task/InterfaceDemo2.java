package Task;

public class InterfaceDemo2 {
public static void main(String[] args) {
	Mabu a=new Mabu();
	a.attendscl();
}
}
interface tutionsir{
	void teachtuition();
	void attendtuition();
}
interface sclsir{
	void teachscl();
	void attendscl();
}
interface clgsir{
	void teachclg();
	void attendclg();
}
class Mabu implements tutionsir,clgsir{
	public void teachtuition() {
		
	}
	public void attendscl() {
		// TODO Auto-generated method stub
		System.out.println("attending scl");
		
	}@Override
	public void attendtuition() {
		// TODO Auto-generated method stub
		
	}
	
	public void teachscl() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void attendclg() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void teachclg() {
		// TODO Auto-generated method stub
		
	}
}