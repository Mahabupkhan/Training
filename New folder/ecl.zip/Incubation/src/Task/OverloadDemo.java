package Task;

public class OverloadDemo {
public static void main(String[] args) {
	OverloadDemo o=new OverloadDemo();
	o.add(5,4);
	o.add(3,3,4);
	o.add(1,2.5);
}
public void add(int a,int b) {
	System.out.println(a+b);
}
public void add(int a,int b,int c) {
	System.out.println(a+b+c);
}
void add(int i,double f) {
	System.out.println(i+f);
}

}
