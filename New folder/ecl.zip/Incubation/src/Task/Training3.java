package Task;

public class Training3 {

	public static void main(String[] args) {
	// tamils t=new tamils();
	// t.food();
	 //t.aadhar();
	}

}
abstract class indian{
	abstract void food() ;
	abstract void culture();
		
	
	void aadhar() {
		System.out.println("Aadhar applied");
	}
	void pan() {
		System.out.println("Pan Applied");
	}
}

abstract class tamils extends indian{
	void food() {
		System.out.println("Rice");
	}
	void aadhar() {
		System.out.println("Aadhar applied");
	}
	
}
class telugus {
	void food() {
		System.out.println("Molagai");
	}
}
