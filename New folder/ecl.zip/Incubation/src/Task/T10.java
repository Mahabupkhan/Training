package Task;

public class T10 {

}
