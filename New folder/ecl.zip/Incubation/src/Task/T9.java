package Task;

public class T9 {
   public static void main(String[] args) {
	  PaintBrush brush=new PaintBrush();
	  brush.paint=new Paint();
	  brush.paint.doPaint();
}
}
class PaintBrush{
	Paint paint;
}
class Paint{
	public void doPaint() {
		System.out.println("Paint....");
	}
}
class RedPaint extends Paint{
	public void doPaint() {
	 System.out.println("RedPaint......");	
	}
}
class BluePaint extends Paint{
	public void doPaint() {
	  System.out.println("BluePaint........");	
	}
}
