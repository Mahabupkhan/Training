package Task;

public class InherDemo {
   public static void main(String[] args) {
	
}
}
interface Flyable{
	public void Fly();
}
abstract class Bird{
   abstract public void Eat();
}
class Dove extends Bird implements Flyable{
   @Override
public void Fly() {
	// TODO Auto-generated method stub
	
}
	@Override
	public void Eat() {
		// TODO Auto-generated method stub
		
	}
}
class Chicken extends Bird{
	@Override
	public void Eat() {
		// TODO Auto-generated method stub
		
	}
	
}
