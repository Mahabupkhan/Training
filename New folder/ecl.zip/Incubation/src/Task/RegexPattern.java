package Task;

public class RegexPattern {
public static void main(String[] args) {
	System.out.println(Print(6.0));
	
}
static {
	System.out.println("welcome");
}
public static double Print(double i) {
	if(i<1)
		return 1;
	//  System.out.println(Print(i));
	return Print(i-1.0)*i;
	
}
}
