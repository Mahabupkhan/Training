package Task;

public class ReturnType {
public static void main(String[] args) {
	fun(0);
	cl1.setter(5);
}
private static void fun(int i) {
	if(i==0) {
	System.out.println("0");
	//return;
	}
	System.out.println("zero");
	
}
//public void getter(int i) {
//	fun(i);
//}
}
class cl1 extends ReturnType{
	public static void setter(int i) {
		ReturnType r=new ReturnType();
		fun(i);
	}
}
