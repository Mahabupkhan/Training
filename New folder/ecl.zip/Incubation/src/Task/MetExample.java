package Task;

public class MetExample {
public static void main(String[] args) {
	int[] arr= {5,6,7,2,1,0,4,2,1,9,0,4,1,2,3,4,5,6};
	int[] arr2=sort2(arr);
	for(int i=0;i<arr2.length;i++)
		System.out.print(arr2[i]+" ");
}
public static void sort(int[] arr) {
	for(int i=0;i<arr.length;i++) {
		int index=i;
		for(int j=i+1;j<arr.length;j++) {
			if(arr[j]<arr[index]) {
				index=j;
			}		
		}
		int temp=arr[i];
		arr[i]=arr[index];
		arr[index]=temp;
	}
}
public static int[] sort2(int[] arr) {
	for(int i=0;i<arr.length;i++) {
		int index=i;
		for(int j=i+1;j<arr.length;j++) {
			if(arr[j]<arr[index]) {
				index=j;
			}		
		}
		int temp=arr[i];
		arr[i]=arr[index];
		arr[index]=temp;
	}
	return arr;
}
}
