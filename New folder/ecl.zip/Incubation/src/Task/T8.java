package Task;
import java.util.Scanner;
public class T8 {
public static void main(String[] args) {
	Scanner scan=new Scanner(System.in);
	System.out.println("Enter array size : ");
	int size=scan.nextInt();
	int[] arr=new int[size];
	
	for( int i=0;i<size;i++) 
		arr[i]=scan.nextInt();
	update(arr);
	
	
		
}
static void update(int arr[]) {
	for(int i=0;i<arr.length;i++) {
		arr[i]=arr[i]+1;
	}
	for( int i=0;i<arr.length;i++)
		System.out.print(arr[i]+" ");
		
}
}
