package Task;

import java.util.Scanner;

public class Occurence {
public static void main(String[] args) {
	Shamsu s=new Shamsu();
	s.print();
	
	System.out.println(afru1.view(1,2));
	System.out.println(s.s("Mahmood"));
}
}
interface afru1{
	int i=0;
	void print();
	void show();
	static int view(int a,int b) {return a+b;}
	default String s(String str) {
		return str+1;
	}
	
}
interface ashath{
	int i=1;
	void print();
	void show();
}
class Shamsu implements afru1{
	@Override
	public void print() {
		System.out.println(i+" "+"afru Print method");
		
	}
	@Override
	public void show() {
		System.out.println("afru show method");
		
	}
}
