package Task;

public class Summa {
	 int j=0;
	static int i=0;
	static Summa s;
	static amma am;
	public static void main(String[] args) {
		System.out.println(i);
 s=new Summa();
 am=new amma();
s.demo1();
s.demo2();
amma a=new amma();
a.print();
	}
	void demo1(){
	 j=10;
	 i=5;
	}
	void demo2() {
		System.out.println(i);
		System.out.println(j);
	}
}
class amma extends Summa{
	public void print() {
		
		System.out.println("print met");
		System.out.println(i);
		
		System.out.println(s.j);
	}
}