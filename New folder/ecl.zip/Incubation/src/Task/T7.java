package Task;

public class T7 {
public static void main(String[] args) {
	String s="w2r3";
	int i=s.charAt(1);
	System.out.println(i);
}
}
