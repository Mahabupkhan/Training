package Task;

public class StaticConstructor {
public static void main(String[] args) {
	Male mahmood=new Male(4,5);
	mahmood.Print();
	Male aslam=new Male(mahmood);
	aslam.Print();
}
}
class Human{
	 String name;
	int age;
	
	
}
class Male{
	int size;
	int height;
	public Male(int size,int height) {
		//super(name,age);
		this.size=size;
		this.height=height;
		
	}
	public Male(Male male) {
		this.size=male.size;
		this.height=male.height;
	}
	public void Print() {
		System.out.println("\nsize"+size+"\nheight"+height);
	}
}
