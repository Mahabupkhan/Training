package Task;

import java.util.Scanner;

public class T5 {
public static void main(String[] args) {
	T5 t=new T5();
	t.sum();
	sub s=new sub();
	//s.sum();
	
	
}
void sum() {
	System.out.println("Parent");
}
}
class sub extends T5{
	void sum() {
		System.out.println("child");
	}  
}
