package Task;

public class Training4 {
	int i=1;
public static void main(String[] args) {
	T t=new T();
	t.print();
	E e=new E();
	e.print1();
}
}
class T extends Training4{
	void print() {
		//System.out.println(i);
	}
}
class E extends T{
	void print1() {
		System.out.println(1+4+"zoho"+1+2+3);
		System.out.println(1+2+3+"zoho"+4+1);
		System.out.println('1'+'2');
		System.out.println(i+i);
		System.out.println(i+""+i);
		
	}
}
