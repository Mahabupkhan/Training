
public class InterDemo {
	
public static void main(String[] args) {
	inter.met1();
}
}
interface inter{
	private static void met() {
		System.out.println("met");
	}
	public static void met1() {
		met();	
	}
	
}
class Kad{
	public void met() {
	
	

}
class mag extends Kad  implements inter{
	public void met() {
		
	}
	public void met1() {
		
	}
	}
}