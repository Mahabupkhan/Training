package patterns;

public class StrategyPattern {
public static void main(String[] args) {
	Dog mabu=new Dog();
	Milk m=new Milk();
	mabu.play(m);
	System.out.println(mabu.getObjectSize());
}
}
class Dog{
	public void play(Item i) {
		i.execute();
	}
}
abstract class Item{
	abstract public void execute();
}
class Milk extends Item{

	@Override
	public void execute() {
		System.out.println("Drink!!!!!!!!!!!!");
		
	}
	
}
class Stick extends Item{

	@Override
	public void execute() {
		System.out.println("Run!!!!!!!!!!");
		
	}
	 
}