package patterns;

import java.util.Scanner;

public class Main2 {
public static void main(String[] args) {
	Scanner scan=new Scanner(System.in);
	System.out.println("Enter length and breadth of 1st Rec : ");
	Rectangle r1=new Rectangle(scan.nextInt(),scan.nextInt());
	System.out.println("Enter length and breadth of 2st Rec : ");
	Rectangle r2=new Rectangle(scan.nextInt(),scan.nextInt());
	
	System.out.println("area of first rec : "+r1.findArea());
	System.out.println("area of 2nd rec : "+r2.findArea());
	
}
}
class Rectangle{
	int length;
	int breadth;
	public Rectangle(int length,int breadth) {
		this.length=length;
		this.breadth=breadth;
	}
	public int findArea() {
		return length*breadth;
	}
}
