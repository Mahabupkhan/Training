package patterns;

public class Main {
public static void main(String[] args) {
	Student ashath=new Student("ashath",22);
	System.out.println(ashath.name);
	int i=0;
	i=i;
	
}
}
class Student{
	String name;
	int RollNo;
	public Student(String name,int RollNo) {
		this.name=name;
		this.RollNo=RollNo;
	}
}