package patterns;

public class shamsu {
public static void main(String[] args) {
	mabu m=new mabu();
	mabu m1=new mabu();
	m=m1;
	m.met();
	m.met2();
	m=null;
	System.gc();
}
}
class mabu{
	void met() {
		System.out.println("met 1");
	}
	void met2() {
		System.out.println("met 2");
	}
	public void finalize() {
		System.out.println("asasasas");
	}
}