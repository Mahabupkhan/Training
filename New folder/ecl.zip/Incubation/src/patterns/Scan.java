package patterns;

import java.util.Scanner;

public class Scan {
public static void main(String[] args) {
	Scan s=new Scan();
	s.met();
}
public void met() {
	System.out.println("met");
	met1();
}
public void met1() {
	System.out.println("met1");
}
}
