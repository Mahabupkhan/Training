
public class OverRideDemo {
public static void main(String[] args) {
	Human h=new Afru();
	h.eat();
}
}
class Human{
	void eat() {
		System.out.println("Rice");
	}
}
class Shamsu extends Human{
	void eat() {
		System.out.println("Chapathi");
	}
}
class Afru extends Human{
	void eat() {
		System.out.println("Idly");
	}
}