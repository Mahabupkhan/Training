import java.util.Scanner;

public class Per {
	static int count=0;
   public static void main(String[] args) {
	 Scanner s=new Scanner(System.in);
	 int n=s.nextInt();
	 int arr[]=new int[n];
	 for(int i=0;i<n;i++)
		 arr[i]=s.nextInt();
	 Per(arr,0,n-1);
	System.out.println(count); 
 }
   public static void Per(int arr[],int l,int r) {
	   if(l==r) {
		 printArr(arr);
		 count++;
		 return;
	   }
	   else {
		 for(int i=l;i<=r;i++) {
			arr=swap(arr,l,i);
			Per(arr,l+1,r);
			arr=swap(arr,l,i);
		 }
	   }
		   
   }
   public static int[] swap(int arr[],int i,int j) {
	   int temp=arr[i];
	   arr[i]=arr[j];
	   arr[j]=temp;
	   return arr;   
   }
   public static void printArr(int arr[]) {
	   for(int i=0;i<arr.length;i++)
		   System.out.print(arr[i]);
	   System.out.println();
   }
}
