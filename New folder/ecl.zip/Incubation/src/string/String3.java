package string;

public class String3 {
public static void main(String[] args) {
	StringBuffer buff=new StringBuffer("Zoho");
	StringBuilder build=new StringBuilder("Zoho2");
	
	buff.reverse();
	build.reverse();
	System.out.println(buff);
	System.out.println(build);
	System.out.println(System.currentTimeMillis());
	buff.delete(0,3);
	build.delete(0,3);
	System.out.println(buff);
	System.out.println(build);
	
	buff.insert(0,"d");
	build.insert(0,"D");
	System.out.println(buff);
	System.out.println(build);
	
	buff.replace(1,3,"Hii");
	build.replace(1,3,"Hlo");
	System.out.println(buff);
	System.out.println(build);
	buff.append("mabu");
	System.out.println(buff+"  "+buff.capacity());
	System.out.println(build.capacity());
	System.out.println(System.currentTimeMillis());
	
}
}
