package string;

public class String1 {
public static void main(String[] args) {
	String str="java";
	long startTime=System.currentTimeMillis();
	for(int i=0;i<100000;i++)
		str+=" Tech";
	System.out.println("String : "+(System.currentTimeMillis()-startTime)+" ms");
	StringBuffer sbuffer=new StringBuffer("java");
	startTime=System.currentTimeMillis();
	for(int i=0;i<1000000;i++)
		sbuffer.append(" Tech");
	
	System.out.println("String bufer: "+(System.currentTimeMillis()-startTime)+" ms");
	StringBuilder sbuilder=new StringBuilder("Java");
	startTime=System.currentTimeMillis();
	for(int i=0;i<1000000;i++)
		sbuilder.append(" Tech");
	System.out.println("String builder: "+(System.currentTimeMillis()-startTime)+" ms");
}
}
