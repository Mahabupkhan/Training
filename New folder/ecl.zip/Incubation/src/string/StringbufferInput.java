package string;

import java.util.Scanner;

public class StringbufferInput {
public static void main(String[] args) {
	StringBuffer buff=new StringBuffer();
	Scanner scan=new Scanner(System.in);
	System.out.println("Enter String : ");
	buff.append(scan.next());
	
	System.out.println(buff);
	String output=new String(buff);
	System.out.println(output);
}
}
