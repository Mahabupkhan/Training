import java.beans.JavaBean;

public class ObjDemo {
public static void main(String[] args) {
	cl2 cl=new cl2();
	cl.met();
	cl.met1();
	cl2 cll=new cl2();
	cll.met();
	cll.met1();
	//JavaBean j=new JavaBean();
	
}
}
class cl2{
	static int i;
	static int count=0;
	public   void met() {
		for(int i=0;i<4;i++)
			count++;
	}
	public void met1() {
		System.out.println(count);
	}
}
