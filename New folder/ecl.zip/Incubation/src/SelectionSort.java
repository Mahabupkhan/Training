import java.util.Scanner;

public class SelectionSort {
public static void main(String[] args) {
	Scanner scan=new Scanner(System.in);
	System.out.println("Enter array size : ");
	int size=scan.nextInt();
	int[] arr=new int[size];
	for(int i=0;i<size;i++)
		arr[i]=scan.nextInt();
	for(int i=0;i<size;i++) {
		int index=i;
		for(int j=i+1;j<size;j++) {
			if(arr[j]<arr[index]) {
				index=j;
			}
			
		}
		int smallNum=arr[index];
		arr[index]=arr[i];
		arr[i]=smallNum;
	}
	for(int i=0;i<size;i++)
		System.out.print(arr[i]+" ");
	
}
}
