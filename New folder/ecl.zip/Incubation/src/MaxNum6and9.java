import java.util.Scanner;

public class MaxNum6and9 {
public static void main(String[] args) {
	Scanner scan=new Scanner(System.in);
	System.out.println("Enter hour : ");
	int hour=scan.nextInt();
	System.out.println("Enter minute : ");
	int min=scan.nextInt();
	System.out.println("enter adding hour : ");
	int addhour=scan.nextInt();
	System.out.println("Enter adding minute : ");
	int addmin=scan.nextInt();
	int totalmin=(addhour*60)+addmin;
	min+=totalmin;
	
}
}
