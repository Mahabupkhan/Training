package arraylist;

public class RecusreDemo {
public static void main(String[] args) {
	System.out.println(climbstairs(5,0));
	System.out.println(count);
}
static int count=0;
	public static int climbstairs(int n,int i) {
		if(n==i) {
			count++;
			return 1;
		}
		return climbstairs(n,++i);
	}
}
