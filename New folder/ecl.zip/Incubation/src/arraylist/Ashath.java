package arraylist;

import java.util.ArrayList;

public class Ashath {
public static void main(String[] args) {
	ArrayList<Customer> add=new ArrayList<Customer>();
	add.add(new Customer("Ashath",20));
	System.out.println(add    );
}
}
class Customer{
	String name;
	int age;
	Customer(String name,int age){
		this.name=name;
		this.age=age;
	}
	      
}