package arraylist;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;



public class IteratorDemo {
public static void main(String[] args) {
	ArrayList a=new ArrayList();
	for(int i=1;i<=10;i++) {
		a.add(i);
	}
	    
	//Collections.reverse(a);
	Collections.sort(a);
	Iterator i=a.iterator();
	while(i.hasNext()) {
		System.out.println(i.next());
	}
	}
}

