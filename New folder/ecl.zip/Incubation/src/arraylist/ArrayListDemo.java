package arraylist;

import java.util.ArrayList;

public class ArrayListDemo {
static public  void main(String[] args) {
	ArrayList arr=new ArrayList(30);
	arr.add("Hii");
	arr.add("Hlo");
	arr.add("Hii");
	arr.add("Hlo");
	arr.add("Hii");
	System.out.println(arr);
	arr.remove(arr.indexOf("Hii"));
	System.out.println(arr);
	arr.set(2,"good");
	System.out.println(arr);
	arr.remove(3);
	System.out.println(arr);
	ArrayList arr2=new ArrayList();
	arr2=(ArrayList) arr.clone();
	System.out.println(arr2);
	System.out.println("Hlo".compareTo("Hlo"));
	arr.add(0,"mabu");
	System.out.println(arr);
	arr.add(4,"ten");
	System.out.println(arr);
	System.out.println(arr.contains("ten"));
	
	
}
}
