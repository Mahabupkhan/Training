package arraylist;

import java.util.LinkedList;
import java.util.Stack;

public class Demo1 {
public static void main(String[] args) {
	Stack st=new Stack();
	LinkedList qu=new LinkedList();
	st.add(1);
	st.add(2);
	st.add(3);
	st.add(4);
	qu.addAll(st);
	System.out.println(st);
	int k=st.size();
	for(int i=0;i<k;i++) {
		System.out.println(st.pop());
	}
	System.out.println();
	
	for(int i=0;i<k;i++)
	System.out.println(qu.pop());
}
}
