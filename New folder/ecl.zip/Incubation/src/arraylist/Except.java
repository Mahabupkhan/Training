package arraylist;

import java.util.Scanner;

public class Except {
public static void main(String[] args) {
	Scanner scan=new Scanner(System.in);
	int i=0;
	try {
	 i=scan.nextInt();
	}
	catch(Exception e){
	System.out.println("Liii");
	}
	System.out.println(i);
}
}
