
public class StringDemo {
public static void main(String[] args) {
	String str=new String("mabu");
	String b=" is a boy";
	System.out.println(str.hashCode());
	System.out.println(b.hashCode());
	str=str.concat(b);
	System.out.println(str);
	System.out.println(str.hashCode());
}
}