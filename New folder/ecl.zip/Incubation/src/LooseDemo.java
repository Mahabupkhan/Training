public class LooseDemo {
     public static void main(String[] args) {
		PaintBrush<Paint> brush=new PaintBrush();
	    brush.setObj(new RedPaint());
	    Paint red=brush.getObj();
	    red.doPaint();
		PaintBrush<Water> brush1=new PaintBrush();
		brush1.setObj(new RedColorWater());
		Water redcolorwater=brush1.getObj();
		redcolorwater.doWater();
	}
}

abstract class Paint{
	public abstract void doPaint();
}
class RedPaint extends Paint{
	@Override
	public void doPaint() {
		System.out.println("Red color////////");	
	}
}
abstract class Water{
	public abstract void doWater();
}
class RedColorWater extends Water{
	@Override
	public void doWater() {
		System.out.println("RedColor water.....");
	}
}
class PaintBrush<T>{
	private T obj;
	public void setObj(T obj) {
		this.obj=obj;
	}
	public T getObj() {
		return obj;
	}
}