import java.util.Scanner;

public class RansomMagazine {
public static void main(String[] args) {
	Scanner scan=new Scanner(System.in);
	System.out.println("Enter ransom : ");
	String ransom=scan.next();
	System.out.println("Enter Magazine : ");
	String magazine=scan.next();
	System.out.println(canConstruct(ransom,magazine));
	
	
}
public static boolean canConstruct(String Ransom,String Magazine) {
	boolean result=false;
	String str="";
	for(int i=0;i<Magazine.length();i++) {
		if(Ransom.charAt(0)==Magazine.charAt(i)) {
			for(int j=i;j<Ransom.length();j++) {
				str+=Magazine.charAt(j);
			}
			if(str.equals(Ransom))
				result=true;
		}
		else {
			continue;
		}
	}
	return result;
}
}
