
public class Compet {
public static void main(String[] args) {
	Laddoo mabu=new Laddoo();
	mabu.eatLaddoo();
	mabu.result(mabu);
	Laddoo afru=new Laddoo();
	afru.result(afru);
	
}
}
class Laddoo{
	static int count=0;
	int instancecount=0;
	public void eatLaddoo() {
		count++;
		instancecount++;
	}
	public void result(Laddoo ladd) {
		System.out.println("Total count : "+ladd.count);
		System.out.println("Single man count : "+instancecount);
	}
}
