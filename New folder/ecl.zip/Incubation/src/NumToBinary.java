
import java.util.Scanner;

public class NumToBinary {
public static void main(String[] args) {
	
	DisplayBin(8);
}
public static void DisplayBin(int n) {
	if(n==0) {
		return;
	}
	DisplayBin(n/2);
	System.out.print(n%2);
}
}
