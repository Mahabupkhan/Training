//package seleniumLearning;
package L3;
public class Eva {
	public static void main(String[] args) {
		int i=0;
		met(i);
		System.out.println(i);
		if(1+1+1+1+1==5) {
			System.out.println("True");
		}
		else System.out.println("False");
	}
	public static void met(int i) {
		i++;
	}
}
