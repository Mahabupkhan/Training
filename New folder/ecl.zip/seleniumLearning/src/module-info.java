/**
 * 
 */
/**
 * @author Administrator
 *
 */
module seleniumLearning {
	requires org.seleniumhq.selenium.grid;
}