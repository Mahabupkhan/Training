package railWay;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Scanner;

public class RailWays {
	ArrayList<Train> trains=new ArrayList<Train>();
	ArrayList<Passenger> passenger=new ArrayList<Passenger>();
	Scanner scan=new Scanner(System.in);
	public static void main(String[] args) {
	RailWays r=new RailWays();
	r.deSerialize();
	r.option();
	}
	public void deSerialize() {
		try {
			FileInputStream fi=new FileInputStream("C:\\Users\\Administrator\\Desktop\\Railway\\Trains2");
			FileInputStream fi2=new FileInputStream("C:\\Users\\Administrator\\Desktop\\Railway\\Passengers");
			ObjectInputStream oi=new ObjectInputStream(fi);
			trains=(ArrayList<Train>)oi.readObject();
			ObjectInputStream oi2=new ObjectInputStream(fi2);
			passenger=(ArrayList<Passenger>)oi2.readObject();
			oi.close();
		} catch (FileNotFoundException e) {
			//System.out.println("File Not Found");
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	public void option() {
		int uc;
		System.out.println("Welcome To IRCTC!!!!!");
		do {
		System.out.println("1.Booking\n2.get PNR status\n3.BookedTickets\n4.CancelTickets\n5.SearchPassenger"
				+ "\n6.Change ticket status of passenger\n7.List trains\n8.Add trains\n9.Exit");
		uc=scan.nextInt();
		switch(uc) {
			case 1 :bookTicket();break;
			case 2 :getPNRStatus();break;
			case 3 :viewBookedTickets();break;
			case 4 :cancelTickets();break;
			case 5 :searchPassenger();break;
			case 6 :changeTicketStatus();break;
			case 7 :listTrains();break;
			case 8 :addTrains();break;
			case 9:exit();
		}
		}while(uc!=9);
	}
	static int pnr=1234;
	public void bookTicket() {
		System.out.println("Welcome to Booking....");
		System.out.println("Enter From station : ");
		String From=scan.next();
		System.out.println("Enter to Station : ");
		String to=scan.next();
		System.out.println("Available Trains : ");
		for(int i=0;i<trains.size();i++) {
			if(trains.get(i).getFrom().equals(From) && trains.get(i).getTo().equals(to))
				System.out.println(trains.get(i));
		}
		System.out.println("Enter Train No : ");
		int trainNo=scan.nextInt();
		int index=-1;
		for(int i=0;i<trains.size();i++) {
			if(trains.get(i).getTrainNo()==trainNo) {
				index=i;
				break;
			}
		}
		System.out.println("Enter Number Of passengers : ");
		int pcount=scan.nextInt();
		Passenger[] p=new Passenger[pcount];
		for(int i=0;i<pcount;i++) {
			System.out.println("Passenger "+(i+1));
			System.out.println("Enter passenger name : ");
			String name=scan.next();
			System.out.println("Enter Age : ");
			int age=scan.nextInt();
			System.out.println("Enter gender : (Male/Female/Transgender)");
			String gender=scan.next();
			System.out.println("Enter Id : ");
			int id=scan.nextInt();
			if(trains.get(index).getSeats()>0)
			p[i]=new Passenger(name,age,gender,id,pnr,"CNF",trains.get(index));
			else
			p[i]=new Passenger(name,age,gender,id,pnr,"WL",trains.get(index));
			
		}
		System.out.println("Total Fair : "+(trains.get(index).getFair()*pcount));
		System.out.println("1.Pay\n2.cancel\n3.Reschedule");
		int op=scan.nextInt();
		if(op==1) {
			for(int i=0;i<p.length;i++) {
				if(p[i].getTicketStatus().equals("CNF")) {
					passenger.add(p[i]);
					trains.get(index).CNF.add(p[i]);
					trains.get(index).DecSeats();
				}
				else if(p[i].getTicketStatus().equals("WL")) {
					passenger.add(p[i]);
					trains.get(index).WL.add(p[i]);
				}
			}
			System.out.println("Ticket(s) Booked Suucessfully");
			System.out.println("Ticket Details :");
			System.out.println("Train Details : ");
			System.out.println(trains.get(index)+"|| PNR no : "+pnr+"Total fair : "+(trains.get(index).getFair()*pcount));
			System.out.println("Passenger Details : ");
			for(int i=0;i<p.length;i++) {
				System.out.println(p[i]);
			}
		}
		else {
			System.out.println("ticket(s) cancelled...");
		}
		
	}
	public void getPNRStatus() {
		System.out.println("Enter PNR number : ");
		int pnr=scan.nextInt();
		System.out.println("Train Details : ");
		for(int i=0;i<passenger.size();i++) {
			if(passenger.get(i).getPnr()==pnr) {
				System.out.println(passenger.get(i).getTrain());
				break;
			}
		}
		System.out.println("Passenger Details : ");
		for(int i=0;i<passenger.size();i++) {
			if(passenger.get(i).getPnr()==pnr) {
				System.out.println(passenger.get(i));
			}
		}
		
	}
	public void viewBookedTickets() {
		System.out.println("Total Tickets booked : "+passenger.size());
		for(int i=0;i<passenger.size();i++) {
			System.out.println("Passenger "+(i+1));
			System.out.println("Train Details : ");
			System.out.println(passenger.get(i).getTrain());
			System.out.println("Passenger Details : ");
			System.out.println(passenger.get(i));
		}
	}
	public void cancelTickets() {
		System.out.println("Enter your PNR number : ");
		int pnr=scan.nextInt();
		System.out.println("Do you want to cancel the ticket(s)?\n1.Yes\n2.No");
		int op=scan.nextInt();
		if(op==1) {
			for(int i=0;i<trains.size();i++) {
				for(int j=0;j<trains.get(i).CNF.size();j++) {
					if(trains.get(i).CNF.get(j).getPnr()==pnr) {
						trains.get(i).CNF.remove(trains.get(i).CNF.get(j));
						//if(trains.get(i).WL.peek()!=null) {
							trains.get(i).WL.peek().setTicketStatus("CNF");
						trains.get(i).CNF.add(trains.get(i).WL.poll());
						//}
					}
				}
			}
			System.out.println("Amount will be Refunded soon...");
		}
		else if(op==2) {
			System.out.println("Ticket(s) not cancelled...");
		}
		else {
			System.out.println("Wrong option!!!");
		}
	}
	public void searchPassenger() {
		System.out.println("Enter passenger Id to search : ");
		int id=scan.nextInt();
		for(int i=0;i<passenger.size();i++) {
			if(passenger.get(i).getId()==id) {
				System.out.println(passenger.get(i));
				break;
			}
		}
	}
	public void changeTicketStatus() {
		System.out.println("Enter PNR no : ");
		int pnr=scan.nextInt();
		for(int i=0;i<passenger.size();i++) {
			if(passenger.get(i).getPnr()==pnr) {
				//if(!passenger.get(i).ticketStatus.equals("WL"))
				System.out.println(passenger.get(i));
				System.out.println("Your current ticket status is : "+(passenger.get(i).getTicketStatus()));
				System.out.println("Change to 1.CNF 2.Cancelled");
				int op=scan.nextInt();
				if(op==1) {
					if(passenger.get(i).getTrain().getSeats()>0) {
						passenger.get(i).setTicketStatus("CNF");
						System.out.println("ticket status changed to CNF");
					}
					else {
						Train t=passenger.get(i).getTrain();
						for(int j=0;j<t.CNF.size();j++) {
							if(t.CNF.get(i).getPnr()==pnr) {
								t.CNF.remove(i);
							}
						}
						passenger.remove(i);
						System.out.println("Tickets Canclled Sucessfully...");
					}
				}
			}
		}
	}
	public void listTrains() {
		System.out.println("Totally "+trains.size()+" Trains Added...");
		for(int i=0;i<trains.size();i++) {
			System.out.println(trains.get(i));
			System.out.println();
		}
	}
	public void addTrains() {
		System.out.println("Enter Train No : ");
		int trainNo=scan.nextInt();
		System.out.println("Enter Train name : ");
		String trainName=scan.next();
		System.out.println("Enter From Station : ");
		String from=scan.next();
		System.out.println("Enter To station : ");
		String to=scan.next();
		System.out.println("Enter Departure time : ");
		int dep=scan.nextInt();
		System.out.println("Enter Arrival Time : ");
		int arrival=scan.nextInt();
		System.out.println("Enter InBetween station count : ");
		int count=scan.nextInt();
		String[] inbetween=new String[count];
		for(int i=0;i<count;i++) {
			System.out.print("Enter Station Number "+(i+1)+" : ");
			inbetween[i]=scan.next();
		}
		System.out.println("Enter Fair Amount : ");
		int fair=scan.nextInt();
		System.out.println("Enter total number of seats : ");
		int seat=scan.nextInt();
		trains.add(new Train(trainNo,trainName,from,to,dep,arrival,inbetween,fair,seat));
		System.out.println(trainName+" added Successfully...");
		
	}
	public void exit() {
		try {
			FileOutputStream Tra=new FileOutputStream("C:\\Users\\Administrator\\Desktop\\Railway\\Trains2");
			FileOutputStream pas=new FileOutputStream("C:\\Users\\Administrator\\Desktop\\Railway\\Passengers");
			ObjectOutputStream Tra2=new ObjectOutputStream(Tra);
			Tra2.writeObject(trains);
			ObjectOutputStream pas2=new ObjectOutputStream(pas);
			pas2.writeObject(pas);
			System.out.println("Trains Stored In Files....");
		} catch (FileNotFoundException e) {
			System.out.println("File Not Found");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
